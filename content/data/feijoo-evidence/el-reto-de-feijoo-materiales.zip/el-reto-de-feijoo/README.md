# Materiales del reto de Feijoo

Selección de código, datos y pruebas que acompaña al post. Recuento de esta versión: **diez casos estrictos y dos fronterizos**. Las fichas separan el dictamen actual de las reservas; no incluyen la conversación de los agentes ni todas las notas de trabajo.

## Contenido de la descarga

- `cases/`: doce fichas de los casos del recuento principal, con los textos enfrentados, referencias, prueba decisiva y límites. Las imágenes originales recortadas están en `images/`; `image_sources.json` documenta sus fuentes y créditos.
- `data/cases.csv`: 61 registros del seguimiento, incluidos casos cortos, citados, rechazados, duplicados y fuentes ajenas al reto. No son 61 préstamos. `novelty` se refiere a la bibliografía consultada, y no prueba novedad absoluta.
- `checks.md`: estado de las reservas del recuento, con las búsquedas disponibles y lo que sigue sin comprobarse.
- `scripts/`: código de la búsqueda LaBSE, recuperación y alineación de regiones, evaluación, traducción al francés y alineación léxica. También se incluyen el cálculo del benchmark OCR y las figuras del pipeline y del benchmark.
- `data/ocr_bench/`: tres transcripciones de referencia y las salidas OCR disponibles para esas páginas; `scores.json` conserva los resultados de la comparación.
- `data/feijoo/`: segmentos de búsqueda para TCU I–III y IV–V, y texto estructurado I–III usado por los scripts de preparación.
- `data/trevoux/ia/`: un tomo de ejemplo de Trévoux de 1716, con el OCR ABBYY original descargado de Internet Archive. El OCR rehecho del corpus completo no se redistribuye aquí.
- `data/eval/planted.jsonl`: 200 inserciones artificiales, 50 pasajes en cuatro niveles. `out/v3/model.json` guarda los pesos del ranking. Las posiciones de este conjunto corresponden al corpus de la evaluación original, no a una muestra reducida.
- `examples/demo_labse.py`: comparación pequeña de textos franceses y españoles, usando el modelo real.
- `manifest.json`: lista de archivos, tamaños y SHA-256. `environment.json`: versiones observadas en los entornos de la investigación. Los modelos y la caché de embeddings no se incluyen.

## Comprobar el benchmark OCR

Desde la raíz de la descarga, con Python:

```sh
cd data/ocr_bench
python ../../scripts/ocr/score_bench.py
```

Solo usa la biblioteca estándar. Calcula la media de los errores por página, con normalización de ligaduras, s larga y palabras partidas. El alineamiento permite texto adicional al principio y al final de la salida OCR. Es una muestra de tres páginas de Trévoux, de 1703, 1716 y 1729; BSB tiene salida para dos. No es un benchmark de todo el corpus ni de todos los modelos mencionados en los apuntes.

## Ejecutar el ejemplo de LaBSE

```sh
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python examples/demo_labse.py
```

La primera ejecución descarga `sentence-transformers/LaBSE`. El ejemplo imprime una matriz de similitudes coseno; no estima la probabilidad de copia ni reproduce los resultados del corpus completo. Los textos históricos completos de cada ejemplo se consultan en sus fichas.

## Ejecutar el detector sobre el tomo incluido

```sh
.venv/bin/python scripts/match_v3.py --fmt ia --vols memoirespourlhis1716unse --no-jds --no-v2 --threads 4 --out out/demo --tsv out/demo.tsv
```

Este comando busca en **un solo tomo**, usando los segmentos I–III incluidos y los pesos guardados. No reproduce el recall 42/50 ni el recuento histórico final. Para repetir la búsqueda completa hay que aportar el corpus, manteniendo los identificadores y las ediciones. `FEIJOO_SET=4-5` selecciona los segmentos IV–V; `FEIJOO_OCR_DIR` permite indicar el directorio de OCR rehecho, que por defecto es `data/trevoux/ocr/` dentro de esta descarga. El cambio de ruta es la única adaptación de portabilidad en los scripts publicados.

Los scripts de traducción necesitan un modelo convertido de `Helsinki-NLP/opus-mt-es-fr` en `data/cache/mt_align/opus-mt-es-fr-ct2`. Se publica el código, pero no el modelo convertido ni toda la traducción del corpus. Las dependencias del benchmark de reconocimiento Kraken son distintas de las de la búsqueda y se enumeran en `requirements-ocr.txt`.

## Fuentes y créditos

TCU: [Filosofía en español](https://www.filosofia.org/bjf/bjft000.htm), transcripción de ediciones posteriores utilizada para buscar; cada acierto se cotejó con la primera edición. Primeras ediciones: [BNE Digital](https://bnedigital.bne.es/) y [USC Minerva](https://hdl.handle.net/10347/7540). Los recortes BNE conservan el crédito de Biblioteca Nacional de España, CC BY 4.0.

Trévoux: [Internet Archive, ejemplar Getty de 1716](https://archive.org/details/memoirespourlhis1716unse), y [BSB/MDZ](https://www.digitale-sammlungen.de/). Las imágenes son recortes de escaneos, a veces unidos con separación visible; los subrayados de la web se dibujan encima y no alteran los originales descargables. Los metadatos mantienen los créditos y condiciones identificadas por cada proveedor.

Modelos: [LaBSE](https://huggingface.co/sentence-transformers/LaBSE), [artículo de Feng et al.](https://aclanthology.org/2022.acl-long.62/), [OPUS-MT](https://huggingface.co/Helsinki-NLP/opus-mt-es-fr). Referencias metodológicas: [Hinderks et al.](https://doi.org/10.1080/01615440.2026.2675558) y [Roe, Olsen y Morrissey](https://hal.science/hal-03740005).
