"""Small LaBSE cosine example. First run downloads the model weights."""
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('sentence-transformers/LaBSE', device='cpu')
es = ['El anillo permite conocer los pensamientos de aquellos con quienes trate.', 'Los anillos están hechos de plomo y llevan una turquesa.', 'La luz del Sol estuvo pálida durante un año.']
fr = ['Les pensées de ceux avec qui il aura à traiter lui seront découvertes.', 'Il faut faire un anneau de plomb avec une turquoise.', 'La lumière du soleil parut pâle pendant un an entier.']
a = model.encode(es, normalize_embeddings=True)
b = model.encode(fr, normalize_embeddings=True)
print('Filas: español. Columnas: francés. Similitud coseno:')
print((a @ b.T).round(3))
