"""Shared look for the blog figures: palette, fonts, helpers.

Palette: the validated categorical order from the dataviz reference palette
(blue, orange, aqua first; these three pass the all-pairs CVD check).
Every colour that carries meaning also has a text label or a legend entry.
"""
from pathlib import Path
import csv
import datetime as dt

import matplotlib as mpl
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]          # feijoo/
OUT = ROOT / "figures"
POLEMIC_CSV = ROOT / "data" / "polemic" / "polemic_1726_1750.csv"
CASES_CSV = ROOT / "data" / "cases.csv"

# ink and chrome
SURFACE = "#ffffff"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"

# roles
FEIJOO = "#2a78d6"     # blue: Feijoo
CONTRA = "#eb6834"     # orange: detractors
PRO = "#1baf7a"        # aqua: defenders
OTRO = "#8c8a84"       # gray: Trévoux, the Crown, neutral

# case status (fig 1b and fig 3)
ST_CONF = "#2a78d6"    # confirmado con reservas
ST_UMBRAL = "#86b6ef"  # en el umbral (lighter step of the same blue)
ST_BAJO = "#cfe0f5"    # dependiente pero bajo el umbral (lightest step of the blue)
ST_CITADO = "#1baf7a"  # traducido y citado
ST_RECH = "#b9b7b0"    # rechazado
STATUS = {
    "conf": ("Confirmado (con reservas)", ST_CONF),
    "umbral": ("En el umbral", ST_UMBRAL),
    "bajo": ("Dependiente, bajo el umbral", ST_BAJO),
    "citado": ("Traducido y citado", ST_CITADO),
    "rech": ("Rechazado", ST_RECH),
}

MESES = ["ene", "feb", "mar", "abr", "may", "jun",
         "jul", "ago", "sep", "oct", "nov", "dic"]


def setup():
    mpl.rcParams.update({
        "font.family": "Inter",
        "font.size": 10,
        "text.color": INK,
        "axes.edgecolor": AXIS,
        "axes.labelcolor": INK2,
        "axes.facecolor": SURFACE,
        "figure.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "xtick.labelcolor": INK2,
        "ytick.labelcolor": INK2,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",      # keep text as text in the SVG
        "hatch.linewidth": 0.8,
    })


def header(fig, title, subtitle, y=0.985, x=0.03):
    fig.text(x, y, title, fontsize=14, fontweight="semibold", va="top", ha="left")
    fig.text(x, y - 0.032 * (10.5 / fig.get_figheight()), subtitle,
             fontsize=10, color=INK2, va="top", ha="left")


def footer(fig, text, y=0.012, x=0.03):
    fig.text(x, y, text, fontsize=7.5, color=MUTED, va="bottom", ha="left",
             linespacing=1.35)


def save(fig, stem):
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{stem}.svg")
    fig.savefig(OUT / f"{stem}.png", dpi=200)
    print("wrote", OUT / f"{stem}.svg", OUT / f"{stem}.png")


def read_csv(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def parse_date(s):
    """'1729-05-31' | '1729-05' | '1729' -> decimal year (month -> 15th, year -> 1 Jul)."""
    s = s.strip()[:10]
    parts = s.split("-")
    y = int(parts[0])
    m = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() and len(parts[1]) == 2 else 7
    d = int(parts[2][:2]) if len(parts) > 2 and parts[2][:2].isdigit() else (15 if len(parts) > 1 else 1)
    t = dt.date(y, m, d)
    start = dt.date(y, 1, 1)
    return y + (t - start).days / 365.25


def dodge(ys, gaps, lo=None, hi=None):
    """Push label positions apart. ys sorted ascending; gaps[i] = min distance
    between label i and label i+1. Returns new positions."""
    out = list(ys)
    for i in range(1, len(out)):
        need = out[i - 1] + gaps[i - 1]
        if out[i] < need:
            out[i] = need
    if hi is not None and out and out[-1] > hi:
        out[-1] = hi
        for i in range(len(out) - 2, -1, -1):
            need = out[i + 1] - gaps[i]
            if out[i] > need:
                out[i] = need
    return out


# ---- cases ---------------------------------------------------------------
TEMAS = {
    "C001": "Manchas solares (Parent)",
    "C002": "Hierro en las cenizas de las plantas",
    "C003": "La abadesa de Fontevrault",
    "C004": "Magallanes y El Hierro (Taillandier)",
    "C005": "Sectas médicas (Barchusen)",
    "C006": "Costumbres de comida (Lémery)",
    "C007": "Mujeres artistas (Monier)",
    "C008": "Cristal y visión (Le Clerc)",
    "C009": "Modos griegos (Bonnet)",
    "C010": "Longevidad (Temple, Molyneux)",
    "C011": "Médicos chinos (Cleyer)",
    "C012": "Vidas de santos (Commanville)",
    "C013": "Rudbeck y la Atlántida",
    "C014": "La vara divinatoria (Le Brun)",
    "C015": "El espejo ustorio (Villette)",
    "C016": "Bellegarde y las mujeres",
    "C017": "Anillos planetarios (Leonardi)",
    "C018": "Café y médicos (Duncan)",
    "C019": "La clave de Nostradamus",
    "C020": "Huesos de gigantes (Molyneux)",
    "C021": "Madame Le Hay (Chéron)",
    "C022": "Elena Cornaro Piscopia",
    "C023": "La monja sangrada (Vallisnieri)",
    "C024": "Madame Dacier, Homero y Virgilio",
    "C025": "El espejo caliente (Le Maire)",
    "C026": "San Ganelón (reliquias)",
    "C027": "Fuerza de las cuerdas (Réaumur)",
    "C028": "Citas de Le François",
    "C029": "300 males de ojos (Woolhouse)",
    "C030": "El verso de Carsughi",
    "C031": "Los versos «de Columela» (Vanière)", "C032": "El oro de Homberg", "C033": "La trituración (Hecquet)",
    "C034": "Sectas médicas modernas (Barchusen)", "C036": "Un milagro de cien (Daubenton)",
    "C038": "Las modas (Henrion)",
    "V2-R003": "Remedios secretos",
}
# TCU first editions, on-sale dates per Campomanes (Caso 14a, 100a, 113a)
TCU = {1726: ("I", "1726-09-03"), 1728: ("II", "1728-04-06"), 1729: ("III", "1729-05-31")}
_MON = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}


# certainty tiers (notes/06 decision 3; blog/cases.csv column "tier")
TIERS = {
    "A": ("A · estricto", ST_CONF),
    "B": ("B · dependiente", ST_UMBRAL),
    "C": ("C · corto", ST_BAJO),
    "D": ("D · traducción citada", ST_CITADO),
    "bajoC": ("Por debajo de C", ST_RECH),
    "rech": ("Rechazados", ST_RECH),
}


def case_tier(t):
    t = t.strip().lower()
    if t.startswith("dup"):
        return "dup"
    if t.startswith("outside"):
        return "fuera"
    if t.startswith("below"):
        return "bajoC"
    if t.startswith("rejected"):
        return "rech"
    return t[0].upper()


def case_status(s):
    s = s.lower()
    if s.startswith("duplicate"):
        return "dup"
    if "outside the dare" in s:
        return "fuera"
    if s.startswith("rejected"):
        return "rech"
    if "translated-and-credited" in s:
        return "citado"
    if "below threshold" in s:
        return "bajo"
    if "threshold" in s:
        return "umbral"
    return "conf"


def load_cases():
    import re
    out = []
    for r in read_csv(CASES_CSV):
        cid = r["id"]
        # duplicates (C035 = C028, C037 = C029), cases outside the dare
        # (O153, O234: Bayle; O469...: Moréri) and the second dare of 1733
        # (D2-*: TCU IV-V, notes/23) are in the CSV but not in the figures
        if case_tier(r.get("tier", "")) in ("dup", "fuera") or cid.startswith("D2-"):
            continue
        src = r["source_date_article"]
        if cid == "C011":
            sy, sm, sd = 1682, 2, 2
        else:
            m = re.match(r"([A-Za-z]{3})[a-z]*(?:-[A-Za-z]+)?\s+(\d{4})", src)
            sm, sy, sd = _MON[m.group(1).lower()], int(m.group(2)), 15
        # first TCU year named in first_ed_pages (C006: III.10 is the main passage)
        ty = int(re.search(r"(1726|1728|1729)", r["first_ed_pages"]).group(1))
        vol, tdate = TCU[ty]
        out.append(dict(
            id=cid, tema=TEMAS.get(cid, cid), status=case_status(r["status"]),
            words=int(r["dependent_words_num"]), words_txt=r["dependent_words_es"],
            journal=r["source_journal"], src_year=sy, src_month=sm,
            src_t=sy + (sm - 1 + (sd - 1) / 30) / 12, tcu_vol=vol, tcu_t=parse_date(tdate),
            tcu_loc=r["tcu_loc"], label=r["label"], tier=case_tier(r.get("tier", "")),
            tier_txt=r.get("tier", ""), row=r))
    return out
