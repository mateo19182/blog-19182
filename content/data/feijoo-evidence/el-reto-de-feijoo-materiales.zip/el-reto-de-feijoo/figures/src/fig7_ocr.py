"""Benchmark local: notes/10-ocr-benchmark.md, §2."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

out = Path(__file__).resolve().parents[1]
labels = ['ABBYY · Internet Archive', 'Tesseract · frm+fra', 'OvisOCR2', 'Churro-3B', 'BSB/MDZ*', 'GLM-OCR', 'Kraken + PP-OCRv6-small', 'Kraken + PP-OCRv6-medium']
values = [7.13, 5.26, 3.72, 1.45, 1.23, .99, .34, .20]
fig, ax = plt.subplots(figsize=(10, 5.8))
fig.patch.set_facecolor('#faf9f6')
ax.set_facecolor('#faf9f6')
ax.barh(labels, values, color=['#8391a0']*7 + ['#187b79'], height=.65)
ax.invert_yaxis()
for i,v in enumerate(values):
    ax.text(v+.10, i, f'{v:.2f} %'.replace('.', ','), va='center', fontsize=11)
ax.set_xlim(0,8.1)
ax.set_xlabel('Error de caracteres (CER, %)')
ax.spines[['top','right','left']].set_visible(False)
ax.tick_params(axis='y', length=0)
ax.xaxis.grid(True, alpha=.18)
ax.set_axisbelow(True)
fig.tight_layout()
fig.savefig(out/'fig7_ocr.png', dpi=180, transparent=True)
fig.savefig(out/'fig7_ocr.svg', transparent=True)
