"""Esquema horizontal del pipeline; SVG y PNG reproducibles."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import style as S

S.setup()
fig, ax = plt.subplots(figsize=(18, 4.5))
fig.subplots_adjust(left=.015, right=.985, top=.97, bottom=.03)
ax.set(xlim=(0, 18), ylim=(0, 5.6))
ax.axis('off')
AUTO = ('#eef4fc', '#2a78d6')
READ = ('#fff1e9', '#cf582e')
DATA = ('#f3f2ee', '#898781')
FINAL = ('#e8f7f0', '#19895f')


def box(x, y, w, h, title, detail, palette=AUTO):
    bg, border = palette
    ax.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle='round,pad=0.015,rounding_size=.12',
        facecolor=bg, edgecolor=border, lw=1.4))
    ax.text(x+w/2, y+h/2, title, fontsize=16, fontweight='semibold',
            ha='center', va='center', linespacing=1.2)


def arrow(points, dashed=False):
    for a, b in zip(points[:-2], points[1:-1]):
        ax.plot([a[0], b[0]], [a[1], b[1]], color=S.MUTED, lw=1.4,
                ls='--' if dashed else '-')
    ax.add_patch(FancyArrowPatch(points[-2], points[-1],
        arrowstyle='-|>', mutation_scale=14, color=S.MUTED, lw=1.4,
        linestyle='--' if dashed else '-', shrinkA=0, shrinkB=4))

# Lectura de izquierda a derecha. Las dos búsquedas convergen en los candidatos.
box(.1, 2.45, 2.3, 1.8, 'Documentos', 'Feijoo · Trévoux\nJournal des Sçavans', DATA)
box(2.85, 2.45, 2.3, 1.8, 'OCR', 'Escaneos → texto\nFrases + referencias')
box(5.7, 3.4, 3, 1.65, 'LaBSE', 'ES ↔ FR\nSimilitud + margen')
box(5.7, 1.35, 3, 1.65, 'Traducir + alinear', 'Palabras poco frecuentes\n+ orden')
box(9.3, 2.45, 2.3, 1.8, 'Candidatos', 'Agrupar pasajes\nQuitar duplicados')
box(12.15, 2.45, 2.75, 1.8, 'Revisar', 'Agentes independientes\n+ cotejo de originales', READ)
box(15.45, 2.45, 2.4, 1.8, 'Resultados', 'Clasificar\nPasajes + enlaces', FINAL)
arrow([(2.4, 3.35), (2.85, 3.35)])
arrow([(5.15, 3.35), (5.42, 3.35), (5.42, 4.22), (5.7, 4.22)])
arrow([(5.42, 3.35), (5.42, 2.17), (5.7, 2.17)])
arrow([(8.7, 4.22), (9, 4.22), (9, 3.35), (9.3, 3.35)])
arrow([(8.7, 2.17), (9, 2.17), (9, 3.35)])
arrow([(11.6, 3.35), (12.15, 3.35)])
arrow([(14.9, 3.35), (15.45, 3.35)])
# Evaluar la búsqueda es distinto de validar la procedencia de un pasaje.
box(9.3, .15, 2.3, 1.6, 'Benchmark', 'Casos artificiales\n42/50 difíciles', DATA)
arrow([(10.45, 2.45), (10.45, 1.75)], dashed=True)
S.save(fig, 'fig6_pipeline')
svg = S.OUT / 'fig6_pipeline.svg'
svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines()) + '\n')
