"""Pipeline completo. Cotejado con scripts/v3_embed.py, match_v3.py y notes/17–18,21.
Genera un gráfico estático reproducible, con ramas y parámetros de la búsqueda.
"""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import style as S

S.setup()
fig, ax = plt.subplots(figsize=(9, 21))
fig.subplots_adjust(left=.025, right=.975, top=.995, bottom=.005)
ax.set(xlim=(0, 9), ylim=(0, 21))
ax.axis('off')
AUTO = ('#eef4fc', '#2a78d6')
READ = ('#fff1e9', '#cf582e')
DATA = ('#f3f2ee', '#898781')
FINAL = ('#e8f7f0', '#19895f')

def box(x, y, w, h, title, lines, palette=AUTO, size=11):
    bg, border = palette
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.015,rounding_size=.09',
                              facecolor=bg,edgecolor=border,lw=1.3))
    ax.text(x+.18,y+h-.18,title,fontsize=13,fontweight='semibold',va='top')
    ax.text(x+.18,y+h-.52,'\n'.join(lines),fontsize=size,color=S.INK2,
            va='top',linespacing=1.28)

def arrow(a,b,label=None):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=12,
                                color=S.MUTED,lw=1.2,shrinkA=3,shrinkB=3))
    if label:
        ax.text((a[0]+b[0])/2+.12,(a[1]+b[1])/2,label,fontsize=9,color=S.INK2,va='center')

box(.2,19.35,8.6,1.4,'1. Descargar y conservar las referencias',[
    'TCU I–V · Trévoux 1701–1732 · Journal des Sçavans de 1682',
    'BNE / USC · Internet Archive · BSB/MDZ · transcripciones y fuentes auxiliares',
    'Guardar edición, fecha, tomo y página junto al texto y al escaneo.'
],DATA)
arrow((4.5,19.35),(4.5,19.05))
box(.2,17.5,8.6,1.55,'2. Obtener texto y comprobar el OCR',[
    'Comparar motores con páginas transcritas; medir error de caracteres.',
    'Trévoux: Kraken + PP-OCRv6-medium · OCR existente en las otras fuentes.',
    'Conservar las imágenes originales para comprobar los pasajes después.',
    'Repetir la búsqueda por tomos a medida que termina el nuevo OCR.'
])
arrow((4.5,17.5),(4.5,17.2))
box(.2,15.8,8.6,1.4,'3. Preparar las unidades de búsqueda',[
    'Quitar cabeceras y números de página; unir palabras partidas; reparar ſ.',
    'Dividir en frases y párrafos, conservando tomo, posición y artículo.',
    'Feijoo: separar adiciones identificadas; cotejar luego con la primera edición.'
])
arrow((3,15.8),(2.3,15.45))
arrow((6,15.8),(6.7,15.45))
box(.2,11.5,4.15,3.95,'4a. LaBSE → regiones → frases',[
    'BERT → [CLS] → Dense + tanh → L2',
    '768 dimensiones · español y francés',
    'CPU, lotes de 32; caché float16 por tomo',
    '',
    'Bloques FR: 8 frases, paso de 4',
    'Consulta ES: párrafo o bloque',
    'Vectores centrados + CSLS, k = 10',
    'Top 12 semánticos + 6 por nombres/cifras',
    'Añadir coincidencias de frases sueltas',
    'Unir regiones; contexto de ±12 frases',
    '',
    'Alinear frases y ventanas de 2–3',
    'Margen por cociente, k = 8',
    'Orden, cobertura; rebajar citas repetidas'
],size=10.2)
box(4.65,11.5,4.15,3.95,'4b. Traducir ES → FR y alinear',[
    'OCR de 1.ª edición + texto limpio',
    'Helsinki-NLP/opus-mt-es-fr',
    'CTranslate2 int8 · traducción en caché',
    '',
    'Normalizar francés antiguo y moderno',
    'Raíces de palabras + frecuencia (IDF)',
    'Ventanas: ES 30 / FR 60 tokens útiles',
    'Pasos de 10 / 20 tokens',
    'Margen frente a 10 vecinos por lado',
    '',
    'Palabras raras y pares de raíces',
    'Comprobar la coherencia de su orden',
    'Agrupar las ventanas próximas',
    'Complementa la búsqueda con LaBSE'
],size=10.2)
arrow((2.3,11.5),(3,11.15))
arrow((6.7,11.5),(6,11.15))
box(.2,9.7,8.6,1.45,'5. Ordenar y reunir candidatos',[
    'LaBSE: regresión logística con margen, cobertura, orden y anclas léxicas.',
    'Reunir las vías de búsqueda; agrupar pasajes cercanos y quitar duplicados.',
    'Crear paquetes con ambos textos, contexto y referencias para la lectura.'
])
arrow((2.3,9.7),(2.3,9.35))
arrow((6.7,9.7),(6.7,9.35))
box(.2,7.25,4.15,2.1,'6a. Evaluar la recuperación',[
    'Positivos conocidos + 200 inserciones',
    '50 pasajes × 4 niveles de dificultad',
    'Validación separada por pasaje',
    'Ajustar / comparar los detectores',
    'Nivel difícil, primeros 148 paquetes:',
    'v3: 42/50 · versión anterior: 27/50',
    'No mide todos los préstamos reales.'
],DATA,size=10.2)
box(4.65,7.25,4.15,2.1,'6b. Leer los candidatos',[
    'Primer agente: dictamen con evidencia',
    'Traducción / paráfrasis / dato / ruido',
    'Segundo agente: dictamen independiente',
    'Sin ver la conclusión del primero',
    'Revisión adversarial de los mejores',
    'Resolver desacuerdos en las fuentes',
    'Añadir pistas encontradas a mano'
],READ,size=10.2)
arrow((6.7,7.25),(4.5,6.9))
box(.2,5.15,8.6,1.75,'7. Volver a los documentos',[
    '¿Está en la primera edición? ¿La revista es anterior al tomo de Feijoo?',
    '¿Puede proceder del libro reseñado o de otra fuente común?',
    'Buscar errores compartidos, recortes y secuencias de detalles distintivos.',
    'Comprobar atribución explícita y contar solo el tramo dependiente.',
    'Cotejar polémica del XVIII y bibliografía posterior: ¿ya se había señalado?'
],READ)
arrow((4.5,5.15),(4.5,4.8))
box(.2,2.95,8.6,1.85,'8. Clasificar y documentar los casos',[
    'Recuento estricto: dependencia específica, sin atribución, unas 35–40 palabras.',
    'Separar los casos fronterizos, cortos, citados, rechazados o con otra fuente.',
    'Reto de 1733: análisis separado; no fija el umbral de las cuatro líneas.',
    'Guardar pasajes enfrentados, páginas, escaneos y reservas de cada dictamen.',
    'La clasificación final depende de estas comprobaciones, no del score.'
],FINAL)
arrow((4.5,2.95),(4.5,2.6))
box(.2,1.15,8.6,1.45,'9. Publicar evidencia y resultados',[
    'Borrador, fichas de casos, imágenes subrayadas y enlaces a los originales.',
    'Figuras reproducibles y código de búsqueda; cambios guardados en Git.',
    'Vista del blog sincronizada con el borrador; revisión en escritorio y móvil.'
],FINAL)
ax.text(.22,.72,'Azul: procesamiento y búsqueda · Naranja: lectura y comprobación',fontsize=10,color=S.INK2)
ax.text(.22,.42,'Gris: documentos / evaluación · Verde: clasificación y publicación',fontsize=10,color=S.INK2)
S.save(fig,'fig6_pipeline')
svg = S.OUT / 'fig6_pipeline.svg'
svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines()) + '\n')
