# Comprobaciones del recuento

Estado al 4 de octubre de 2026. El recuento adoptado es **diez casos estrictos y dos fronterizos**: nueve más dos para TCU I–III y uno adicional para TCU IV–V. El reto de 1733 no repite el umbral de cuatro líneas; aplicar el mismo umbral a la ampliación es una regla de esta investigación.

## Behaim y otras reseñas de Stuvenius

La reserva sobre otras revistas estaba desactualizada en el borrador. La ficha D2-C007 documenta una comprobación del 1 de octubre de 2026:

- *Journal des Sçavans*: París 1716–1717 y reimpresión de Ámsterdam 1715–1717. París 1715 no se localizó, pero se buscó su contenido en la reimpresión de Ámsterdam. Una revisión anterior había buscado en 1714.
- *Acta Eruditorum*: OCR de 1714–1717 y *Supplementa* V de 1713 y VI de 1717, con varios ejemplares en los años disponibles.
- Búsqueda de Stuvenius y variantes, Behaim/Boheme y términos del título y del relato. Como control positivo, el servicio de búsqueda recuperó la reseña conocida de Trévoux en las páginas correspondientes.

Estas búsquedas no encontraron otra reseña que explique la selección, el orden y las expresiones francesas seguidas por Feijoo. Son resultados de búsqueda sobre OCR, no una lectura visual exhaustiva de todas las páginas ni una prueba de inexistencia. La comprobación de la primera edición de 1730 ya estaba hecha: pp. 210–211 del tomo IV, páginas 2517–2518 del PDF compuesto de USC Minerva.

El caso se mantiene en A, con unas 98 palabras estrictas y un mínimo conservador de 39. *Sacra parentalia* de Wagenseil, fuente de Stuvenius, sigue sin leerse. El propio libro de Stuvenius sí se cotejó; la reserva sobre Wagenseil no se presenta como cerrada.

Fuentes accesibles: [Trévoux 1716, segundo tomo, BSB](https://www.digitale-sammlungen.de/en/view/bsb10539855), [Journal, París 1716](https://www.digitale-sammlungen.de/en/view/bsb10501922), [Ámsterdam 1715, tomo 57](https://www.digitale-sammlungen.de/en/view/bsb10539573), [Stuvenius 1714](https://archive.org/details/deveronoviorbisi00stve), [TCU, primeras ediciones de USC](https://hdl.handle.net/10347/7540).

## Las modas y el Mercure galant

C038 sigue siendo fronterizo por dos motivos independientes:

1. La frase tiene 38 palabras bajo el recuento adoptado, pero 30 si el marco de atribución a Henrion y a la Academia se considera información disponible por otras vías. Está impresa en 1728 y ocupa unas cinco líneas más una palabra. El número de palabras no convierte automáticamente todos los marcos de atribución en texto exclusivo de la revista.
2. No se han cotejado íntegramente las entregas de noviembre de 1701 y febrero de 1702 del *Mercure galant*. Las búsquedas ya hechas en diciembre de 1701 y marzo/abril de 1702, y en el *Journal* de 1701–1702, no localizaron el pasaje.

El 4 de octubre se consultaron directamente las selecciones OBVIL de noviembre de 1701 y febrero de 1702. No contienen la noticia de Henrion, pero son selecciones, por lo que ese resultado no cierra la reserva. Se localizó el identificador Gallica de noviembre de 1701, `bpt6k62752174`, a partir de una referencia a un enigma de las pp. 360–361. La consulta del volumen, su texto bruto y su manifiesto IIIF devolvió HTTP 403; no se obtuvo el ejemplar completo.

Fuentes: [OBVIL, noviembre 1701](https://obtic.huma-num.fr/obvil-web/corpus/mercure-galant/MG-1701-11), [OBVIL, febrero 1702](https://obtic.huma-num.fr/obvil-web/corpus/mercure-galant/MG-1702-02), [Gallica, noviembre 1701](https://gallica.bnf.fr/ark:/12148/bpt6k62752174), [Trévoux, febrero 1702](https://archive.org/details/memoirespourlhis1702unse), [Feijoo, Las modas](https://www.filosofia.org/bjf/bjft206.htm).

La clasificación no cambia. Si otro impreso anterior ofrece la misma formulación, habrá que rebajar la atribución exclusiva a Trévoux. No debe contarse como uno de los diez casos claros.

## Vidas de santos

C012 se mantiene separado como fronterizo. Su recuento final de unas 48–51 palabras cuenta únicamente la frase sobre notarios, relatos de santos y Gelasio. Se retiró el tramo sobre el libro de Commanville porque podía proceder del propio libro. La ficha conserva el paralelo concreto y explica esa sustracción; no suma todo el párrafo como si fuera material exclusivo de Trévoux.

## Qué significa el recuento

A: dependencia específica que supera el umbral adoptado. A fronterizo: caso que se mantiene por una lectura particular del tramo o con una reserva relevante. B: dependencia probable con una fuente alternativa o un recuento más amplio. C: tramo corto. D: traducción reconocida por Feijoo, mostrada por separado. Duplicados, rechazos y casos ajenos al reto no se suman al resultado principal.

Las 633 decisiones de la primera búsqueda incluyen tres paquetes vueltos a juzgar; no son 633 descubrimientos ni 633 casos independientes. Las 237 decisiones de la ampliación tampoco son el número de préstamos. La tabla descargable conserva los 61 registros de seguimiento, incluidos duplicados, rechazos y fuentes ajenas a los retos.

«No se localizó una identificación previa» se limita a la bibliografía consultada. No demuestra que nadie haya observado antes el pasaje. La ausencia de otras coincidencias en la búsqueda tampoco demuestra que el corpus esté libre de otros préstamos.
