#!/usr/bin/env python3
"""Text that cannot count for the dare (data/feijoo/exclusions.json; notes/17 "Incremental").

Two kinds:
  - first-edition text that is not Feijoo's own (aprobaciones, licencias, tasas, errata, indexes, title pages, Martín
    Martínez's Carta defensiva in TCU II 1728). These are ranges of MT fe1 segments (data/cache/mt_align/feijoo_segments.jsonl).
  - working-text paragraphs (segments_v3 pids) that are post-first-edition (post_first) or listed in
    exclusions.json working_text.not_feijoo_pids.

usage:
  exclusions.py check       validate the ranges against the segment file, print counts per range
  exclusions.py verdicts    list judged packets (out/verdicts/*.json) whose Feijoo side is excluded (read-only)
"""
import os, sys, re, json, glob, collections

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
EXCL = f'{ROOT}/data/feijoo/exclusions.json'
FSEG = f'{ROOT}/data/cache/mt_align/feijoo_segments.jsonl'
SEGV3 = f'{ROOT}/data/feijoo/segments_v3.jsonl'


class Exclusions:
    def __init__(self, strict=True):
        self.cfg = json.load(open(EXCL))
        self.segs = [json.loads(l) for l in open(FSEG)]
        self.order = {s['id']: i for i, s in enumerate(self.segs)}
        self.fe1 = {}                       # fe1 seg id -> range id
        self.problems = []
        for r in self.cfg['firsted']:
            a, b = self.order.get(r['from']), self.order.get(r['to'])
            if a is None or b is None or b < a:
                self.problems.append(f"{r['id']}: boundary id missing or reversed ({r['from']} .. {r['to']})"); continue
            for key, i in (('first_text', a), ('last_text', b)):
                if not self.segs[i]['es'].startswith(r[key]):
                    self.problems.append(f"{r['id']}: {key} mismatch at {self.segs[i]['id']}: {self.segs[i]['es'][:50]!r}")
            for s in self.segs[a:b + 1]:
                if s['stream'] != 'fe1' or s['vol'] != r['vol']:
                    self.problems.append(f"{r['id']}: range crosses into {s['id']}"); break
                self.fe1[s['id']] = r['id']
        if self.problems and strict:
            raise SystemExit('exclusions.json does not fit the segment file:\n  ' + '\n  '.join(self.problems))
        wt = self.cfg['working_text']
        self.not_feijoo = set(wt.get('not_feijoo_pids', []))
        self.post_first = {}
        for l in open(SEGV3):
            x = json.loads(l)
            # disc=None pids collide (Dedicatoria / Prólogo both '1.None.1'): a pid counts as post-first only if every
            # paragraph carrying it is post-first
            self.post_first[x['pid']] = self.post_first.get(x['pid'], True) and bool(x['post_first'])
        # prefix index for recovering the Feijoo segments behind an MT row's 'es' text
        self.pre = collections.defaultdict(list)
        for i, s in enumerate(self.segs):
            self.pre[self._k(s['es'])].append(i)

    @staticmethod
    def _k(t): return re.sub(r'\s+', ' ', t)[:18]

    # ---------------------------------------------------------------- working text
    def pid_reason(self, pid):
        if pid in self.not_feijoo: return 'not_feijoo'
        if self.post_first.get(pid): return 'post_first'
        return None

    def pids_reason(self, pids):
        """'post_first' / 'not_feijoo' / 'post_first+not_feijoo' when every pid is excluded, else None."""
        pids = [p for p in pids if p]
        if not pids: return None
        rs = [self.pid_reason(p) for p in pids]
        if any(r is None for r in rs): return None
        return '+'.join(sorted(set(rs)))

    # ---------------------------------------------------------------- MT side
    def mt_segments(self, es):
        """Segments of the top MT passage whose Spanish text starts `es` (report.py keeps the first 400 chars of the
        joined segment texts). Returns (stream, [seg ids]) or (None, []) when the text cannot be placed unambiguously."""
        es = re.sub(r'\s+', ' ', es or '').strip()
        if len(es) < 18: return None, []
        best = []
        norm = lambda j: re.sub(r'\s+', ' ', self.segs[j]['es']).strip()
        for i in self.pre.get(self._k(es), []):
            ids, pos, j = [], 0, i
            while j < len(self.segs) and pos < len(es):
                rest = es[pos:]
                # the MT record list can skip a segment of the file, so look a few segments ahead for the continuation
                nxt = next((k for k in range(j, min(j + (1 if not ids else 4), len(self.segs)))
                            if self.segs[k]['stream'] == self.segs[i]['stream'] and self.segs[k]['vol'] == self.segs[i]['vol']
                            and (rest.startswith(norm(k)) or norm(k).startswith(rest))), None)
                if nxt is None: break
                ids.append(self.segs[nxt]['id']); pos += len(norm(nxt)) + 1; j = nxt + 1
            if ids and (pos >= len(es) or len(ids) >= 2 or len(norm(i)) >= 40):
                best.append(ids)
        if not best: return None, []
        if len(best) > 1 and len({self.fe1_reason(b) for b in best}) > 1: return None, []   # ambiguous
        b = max(best, key=len)
        return b[0].split(':')[0], b

    # ---------------------------------------------------------------- fe1 → working-text paragraph ids
    def _para_index(self):
        if hasattr(self, '_P'): return
        import math, unicodedata
        fold = lambda s: ''.join(c for c in unicodedata.normalize('NFD', s.lower()) if unicodedata.category(c) != 'Mn')
        self._tok = lambda s: set(re.findall(r'[a-zñ]{5,}', fold(s)))
        P = [json.loads(l) for l in open(SEGV3)]
        df = collections.Counter()
        toks = []
        for x in P:
            t = self._tok(x['text']); toks.append(t); df.update(t)
        self._idf = {w: math.log(len(P) / c) for w, c in df.items()}
        self._inv = collections.defaultdict(list)
        for i, t in enumerate(toks):
            for w in t: self._inv[w].append(i)
        self._P = P

    def seg_pid(self, sid, thr=0.45):
        """Working-text paragraph (segments_v3 pid) holding a first-edition sentence: idf-weighted share of the
        sentence's words (>=5 letters, df<200) found in the paragraph, same volume, best paragraph >= thr and clearly
        ahead of the runner-up. None for excluded (non-Feijoo) segments and for sentences that do not place."""
        if sid in self.fe1 or not sid.startswith('fe1:'): return None
        self._para_index()
        s = self.segs[self.order[sid]] if sid in self.order else None
        if not s: return None
        q = [w for w in self._tok(s['es']) if w in self._idf and len(self._inv[w]) < 200]
        tot = sum(self._idf[w] for w in q)
        if len(q) < 4 or not tot: return None
        sc = collections.Counter()
        for w in q:
            for i in self._inv[w]:
                if self._P[i]['vol'] == s['vol']: sc[i] += self._idf[w]
        top = sc.most_common(2)
        if not top or top[0][1] / tot < thr: return None
        if len(top) > 1 and top[1][1] > 0.8 * top[0][1]: return None
        return self._P[top[0][0]]['pid']

    def fe1_pids(self, ids):
        return {p for p in (self.seg_pid(i) for i in ids) if p}

    def fe1_reason(self, ids):
        """Range id(s) when every fe1 segment in ids is excluded, else None."""
        ids = list(ids)
        if not ids or any(not i.startswith('fe1:') for i in ids): return None
        rs = [self.fe1.get(i) for i in ids]
        if any(r is None for r in rs): return None
        return 'firsted:' + '+'.join(sorted(set(rs)))


# ------------------------------------------------------------------------------------------ CLI
def check():
    X = Exclusions(strict=False)
    for p in X.problems: print('PROBLEM', p)
    c = collections.Counter(X.fe1.values())
    tot = collections.Counter(s['vol'] for s in X.segs if s['stream'] == 'fe1')
    for r in X.cfg['firsted']:
        print(f"{r['id']:12s} {c[r['id']]:5d} fe1 segments  {r['from']} .. {r['to']}  ({r['kind']})")
    for v in (1, 2, 3):
        n = sum(1 for k in X.fe1 if k.startswith(f'fe1:{v}:'))
        print(f"vol {v}: {n} of {tot[v]} fe1 segments excluded")
    print('working text: post_first pids', sum(X.post_first.values()), '; not_feijoo pids', len(X.not_feijoo))
    return 1 if X.problems else 0


def verdicts():
    """Judged packets whose Feijoo side is excluded. Packet Feijoo side: pids (all formats) and, for MT packets and K
    packets with an MT member, the Spanish text of the aligned passage (→ fe1/fil segments)."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import incremental_candidates as IC
    X = Exclusions()
    V = IC.verdict_labels()
    rows = []
    for d, pre in IC.PRIOR_DIRS:
        for p in sorted(glob.glob(f'{ROOT}/out/{d}/*.md')):
            if not re.search(r'R\d+\.md$', p): continue
            name = pre + os.path.basename(p)[:-3]
            if name not in V: continue
            s = open(p).read()
            pk = IC.parse_packet(p, pre) or {'pids': set()}
            pids = sorted(pk['pids'])
            pr = X.pids_reason(pids)
            es = None
            m = re.search(r'^## Feijoo \(Spanish\)\n(.*?)\n', s, re.M) or \
                re.search(r'^## MT alignment excerpt.*?\nES: (.*?)\n', s, re.M | re.S)
            stream, ids, fr = None, [], None
            if m:
                es = m.group(1)
                stream, ids = X.mt_segments(es)
                fr = X.fe1_reason(ids)
            partial = sorted({X.fe1[i] for i in ids if i in X.fe1}) if ids else []
            scan = re.search(r'1st-ed scan (\d+)', s)
            mixed = [x for x in ('Martínez', 'Martinez') if x in (es or '')]
            if pr or fr or partial:
                rows.append((name, V[name], ','.join(pids) or '-', pr or '', fr or '', ','.join(partial),
                             stream or '', ids[0] if ids else '', scan.group(1) if scan else ''))
            elif m and stream is None:
                rows.append((name, V[name], ','.join(pids) or '-', '', 'mt_side_unresolved', '', '', '', scan.group(1) if scan else ''))
    print('verdict\tlabel\tpids\tpids_excluded\tfirsted_excluded\tfirsted_partial\tmt_stream\tfirst_seg\tscan')
    for r in rows: print('\t'.join(map(str, r)))


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'
    sys.exit({'check': check, 'verdicts': verdicts}[cmd]() or 0)
