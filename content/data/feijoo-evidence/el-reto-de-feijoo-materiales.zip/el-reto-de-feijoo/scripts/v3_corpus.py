"""Matcher v3 corpus layer: Feijoo segmentation + Trévoux loaders (IA djvu.txt, BSB hOCR jsonl, kraken jsonl, JdS txt).
Every loader returns one volume as a list of sentence dicts {vol, fmt, pos, art, leaf, text}; `art` = article index
inside the volume (from 'ARTICLE XXIV' headers, else caps headings, else -1)."""
import os, re, json, gzip, glob, collections, unicodedata
from textnorm import LongS, SENT

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
T_MIN, F_MIN = 40, 25
KRAKEN_DIR = os.environ.get('FEIJOO_OCR_DIR', os.path.join(ROOT, 'data/trevoux/ocr'))
FEIJOO_SET = os.environ.get('FEIJOO_SET', '1-3')   # '4-5' = TCU IV-V for the 1733 dare (notes/23)
SEGMENTS = f'{ROOT}/data/feijoo/segments_v3.jsonl' if FEIJOO_SET == '1-3' else f'{ROOT}/data/feijoo/segments_v3_{FEIJOO_SET}.jsonl'

def fold(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s.lower()) if unicodedata.category(c) != 'Mn')

# ---------------------------------------------------------------- Feijoo
FSPLIT = re.compile(r'(?<=[.!?;:])\s+(?=[A-ZÁÉÍÓÚÑ¿¡«"(])')

def feijoo_segments(rebuild=False):
    """Paragraph (= numbered n. unit) records with their sentences. Cached in data/feijoo/segments_v3.jsonl."""
    if os.path.exists(SEGMENTS) and not rebuild:
        return [json.loads(l) for l in open(SEGMENTS)]
    out = []
    for l in open(f'{ROOT}/data/feijoo/tcu_{FEIJOO_SET}.jsonl'):
        r = json.loads(l)
        sents = [s.strip() for s in FSPLIT.split(r['text']) if len(s.strip()) >= F_MIN]
        out.append({'pid': f"{r['vol']}.{r['disc_num']}.{r['para_seq']}", 'vol': r['vol'], 'disc': r['disc_num'],
                    'title': r['disc_title'], 'para': r['para_seq'], 'label': r.get('para_label'),
                    'section': r.get('section'), 'add': r['is_addition'],
                    'post_first': r.get('post_first_edition', False), 'text': r['text'], 'sents': sents})
    with open(SEGMENTS, 'w') as f:
        for x in out: f.write(json.dumps(x, ensure_ascii=False) + '\n')
    return out

# ---------------------------------------------------------------- Trévoux line cleanup
ART = re.compile(r"^\s*[AÀ]\s*[rR][tT][iIl1íî][cC][lL1][eE]\s+[IVXLCivxlc1lîíTtfJ\.\s]{1,14}\.?\s*\S{0,3}\s*$")
HEAD = re.compile(r"(m[ée]moires?\s+pour|des\s+sciences\s*&|beaux\s+arts|hi[sf]toire\s+des\s+sc)", re.I)
MONTH = re.compile(r"(janv|f[ée]vr|mars|avril|may|mai|juin|juil|ao[uû]st|sept|octob|novem|d[ée]cem)", re.I)

def is_art(ln): return len(ln) < 30 and bool(ART.match(ln))
def is_caps_head(ln):
    letters = [c for c in ln if c.isalpha()]
    return len(letters) >= 14 and sum(c.isupper() for c in letters) / len(letters) > 0.85
def is_junk(ln):
    s = ln.strip()
    if not s: return False
    if len(s) < 40 and HEAD.search(s): return True
    if len(s) < 25 and MONTH.search(s) and re.search(r'1[67]\d', s): return True   # 'Février 1716.'
    if re.fullmatch(r'[\d\s\.,;:\-—_*\'"^]+', s): return True                           # page numbers, rules
    return False

def lines_to_sents(pages, vol, fmt, fix=None, caps_fallback=True):
    """pages: [(leaf, [lines])] in reading order. Dehyphenate across lines/pages, split, tag article + leaf."""
    toks = []   # (leaf, art, line)
    art, n_art = -1, 0
    for leaf, lines in pages:
        for ln in lines:
            ln = ln.replace('ſ', 's').strip()
            if not ln or is_junk(ln): continue
            if is_art(ln):
                n_art += 1; art = n_art; continue
            toks.append([leaf, art, ln])
    if n_art < 3 and caps_fallback:   # no ARTICLE headers (1701–02 issues): caps headings open a new unit
        art = 0
        for t in toks:
            if is_caps_head(t[2]): art += 1
            t[1] = art
    # join lines; keep a char→(leaf,art) map at line starts
    buf, marks = [], []
    for leaf, a, ln in toks:
        if buf and buf[-1].endswith(('-', '¬', '=')):
            buf[-1] = buf[-1][:-1]
            marks.append((sum(map(len, buf)), leaf, a)); buf.append(ln)
        else:
            if buf: buf.append(' ')
            marks.append((sum(map(len, buf)), leaf, a)); buf.append(ln)
    text = ''.join(buf)
    if fix: text = fix(text)
    out, pos, mi, off = [], 0, 0, 0
    for s in SENT.split(text):
        start = text.find(s, off); off = start + len(s)
        while mi + 1 < len(marks) and marks[mi + 1][0] <= start: mi += 1
        s = re.sub(r'\s+', ' ', s).strip()
        if len(s) >= T_MIN:
            out.append({'vol': vol, 'fmt': fmt, 'pos': pos, 'art': marks[mi][2] if marks else -1,
                        'leaf': marks[mi][1] if marks else None, 'text': s})
            pos += 1
    return out

# ---------------------------------------------------------------- loaders
_longs = None
class CleanLongS(LongS):
    """f→s repair for IA ABBYY text (which reads every ſ as f). Frequencies come from OCR that keeps ſ distinct
    (BSB hOCR + finished kraken volumes, ſ→s), so 'son' vs 'fon' is decided by real usage. Table is cached."""
    def fix_word(self, w):
        lw = w.lower()
        if 'f' not in lw: return w
        idx = [i for i, c in enumerate(lw) if c == 'f'][:4]
        best, bf = lw, self.freq[lw]
        for mask in range(1, 1 << len(idx)):
            cand = list(lw)
            for j, i in enumerate(idx):
                if mask >> j & 1: cand[i] = 's'
            cand = ''.join(cand)
            if self.freq[cand] > self.freq[best]: best = cand
        if best == lw or self.freq[best] < max(2, 1.5 * bf): return w
        return ''.join(c2.upper() if c1.isupper() else c2 for c1, c2 in zip(w, best))

def longs_fixer():
    global _longs
    if _longs: return _longs
    p = f'{ROOT}/data/cache/v3/clean_freq.json.gz'
    fx = CleanLongS([])
    if os.path.exists(p):
        fx.freq = collections.Counter(json.load(gzip.open(p, 'rt')))
    else:
        from textnorm import WORD
        c = collections.Counter()
        # kraken keeps ſ reliably (weight 20); BSB hOCR often reads ſ as f (weight 1)
        for f in glob.glob(f'{ROOT}/data/trevoux/bsb/*.jsonl') + glob.glob(f'{KRAKEN_DIR}/*.jsonl'):
            wt = 20 if f.startswith(KRAKEN_DIR) else 1
            for l in open(f):
                r = json.loads(l)
                t = '\n'.join(r['lines'] or []) if 'lines' in r else (r.get('text') or '')
                for w in WORD.findall(t.replace('ſ', 's')): c[w.lower()] += wt
        os.makedirs(os.path.dirname(p), exist_ok=True)
        json.dump({k: v for k, v in c.items() if v > 1}, gzip.open(p, 'wt'))
        fx.freq = c
    _longs = fx; return fx

def load_ia(vol):
    lines = open(f'{ROOT}/data/trevoux/ia/{vol}.txt', errors='replace').read().replace('¬\n', '-\n').splitlines()
    return lines_to_sents([(None, lines)], vol, 'ia', fix=longs_fixer())

def load_kraken(vol, d=KRAKEN_DIR):
    pages = []
    for l in open(f'{d}/{vol}.jsonl'):
        r = json.loads(l)
        ls = [x for x in (r.get('text') or '').split('\n')]
        if ls and len(ls[-1].split()) == 1 and len(ls) > 5: ls = ls[:-1]   # catchword
        pages.append((r['leaf'], ls))
    pages.sort(key=lambda p: p[0])
    return lines_to_sents(pages, vol, 'kraken')

def load_bsb(vol):
    pages = [(r['scan'], r['lines'] or []) for r in map(json.loads, open(f'{ROOT}/data/trevoux/bsb/{vol}.jsonl'))]
    return lines_to_sents(sorted(pages), vol, 'bsb')

def load_jds(vol='jds1682_amsterdam'):
    pages, cur = [], None
    for ln in open(f'{ROOT}/data/jds/{vol}.txt'):
        if ln.startswith('#'): continue
        m = re.match(r'=== (?:p\. (\d+) )?\(?scan (\d+)', ln)
        if m: cur = (int(m.group(2)), []); pages.append(cur); continue
        if cur: cur[1].append(ln.rstrip('\n'))
    return lines_to_sents(pages, vol, 'jds', fix=longs_fixer(), caps_fallback=False)

LOADERS = {'ia': load_ia, 'kraken': load_kraken, 'bsb': load_bsb, 'jds': load_jds}

def list_volumes(fmt, kraken_complete_only=True):
    if fmt == 'ia': return sorted(os.path.basename(p)[:-4] for p in glob.glob(f'{ROOT}/data/trevoux/ia/*.txt'))
    if fmt == 'bsb': return sorted(os.path.basename(p)[:-6] for p in glob.glob(f'{ROOT}/data/trevoux/bsb/*.jsonl'))
    if fmt == 'jds': return ['jds1682_amsterdam']
    if fmt == 'kraken':
        vols = sorted(os.path.basename(p)[:-6] for p in glob.glob(f'{KRAKEN_DIR}/*.jsonl'))
        if kraken_complete_only: vols = [v for v in vols if kraken_done(v)]
        return vols
    raise ValueError(fmt)

def kraken_done(vol):
    """The OCR job writes <ia_id>.done next to the jsonl when a volume is finished."""
    return os.path.exists(f'{KRAKEN_DIR}/{vol}.done')
