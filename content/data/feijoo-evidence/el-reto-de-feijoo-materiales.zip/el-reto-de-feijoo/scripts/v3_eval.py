"""Gold sets and bookkeeping for matcher v3: verified positives, known cases, judged packets, hit tests.
Trévoux regions are found at run time from anchor phrases, so they work on any OCR format (IA / kraken / BSB)."""
import os, re, json, glob, collections
import v3_corpus as C

def N(t): return re.sub('[sf]', 'S', C.fold(t))   # ſ/f/s-insensitive fold

# Verified positives used for real recall: Feijoo paragraph ids (vol.disc.para_seq in tcu_1-3.jsonl) + Trévoux volume + anchors.
REAL = {
    'C001': (['2.14.21', '2.14.22', '2.14.23', '2.14.24'], [('memoirespourlhis1716unse', ['georgiques', 'majolus', 'verre colore', 'taches du soleil'])]),
    'C002': (['2.14.44', '2.14.46', '2.14.47', '2.14.48'], [('memoirespourlhis1707unse', ['lemery', 'plantes'])]),
    'C003': (['1.16.123'], [('memoirespourlhi1704unse_2', ['fontevrault', 'marie therese', 'espagnol avec'])]),
    'C004': (['2.2.120', '2.2.121'], [('memoirespourlhi1715unse_1', ['magellan', 'pampanga', 'lucon|luçon'])]),
    'C005': (['1.5.15', '1.5.16', '1.5.17'], [('memoirespourlhi1710unse_2', ['archigen', 'barchusen', 'juvenal', 'athen'])]),
    'C007': (['1.16.145', '1.16.148'], [('memoirespourlhi1706unse_0', ['angosciola', 'propert', 'lavinia'])]),
    'C009': (['1.14.2'], [('memoirespourlhi1716unse_0', ['phrygien', 'lydien', 'dorien'])]),
    'C010': (['1.12.8'], [('memoirespourlhi1702unse_2', ['nesmond', 'herford']), ('memoirespourlhi1701unse_1', ['eckleston', 'angleterre sçait'])]),
    'C011': (['2.15.22', '2.15.29', '2.15.30'], [('jds1682_amsterdam', ['chinensium', 'poux|pouls', 'renvoye'])]),
    'C012': (['3.6.3', '3.6.4', '3.6.5'], [('memoirespourlhi1701unse_0', ['gelase', 'thecle', 'notaires', 'milieu a tenir'])]),
    'C015': (['2.14.3', '2.14.25'], [('memoirespourlhi1716unse_2', ['vitrifi', 'villette', 'fourneaux', 'miroir'])]),
    'V2-R003': (['2.None.42'], [('memoirespourlhi1709unse_0', ['remedes secrets', 'charlatan', 'petit ecrit'])]),
}
CLEAR = ['C001', 'C002', 'C003', 'C004', 'C005', 'C009', 'C010']
# Rejected / lead cases: only used to flag candidates as already examined (discourse-level match).
OTHER_CASES = {
    'C006': (['3.10', '1.6'], [('memoirespourlhi1702unse_0', ['aliments|alimens'])]),
    'C008': (['3.7'], [('memoirespourlhis1713unse', ['vision']), ('memoirespourlhi1705unse_0', ['clerc', 'deux yeux|un seul oeil|un œil']), ('memoirespourlhi1705unse_1', ['clerc'])]),
    'C013': (['3.10'], [('memoirespourlhis1704unse', ['rudbe'])]),
    'C014': (['3.5'], [('memoirespourlhis1702unse', ['baguette'])]),
    'C016': (['1.16'], [('memoirespourlhi1702unse_0', ['bellegarde'])]),
}

def anchor_region(S, anchors, gap=40, pad=15):
    """Densest cluster of anchor hits → (lo, hi) in sentence positions, or None."""
    hits = []
    for a in anchors:
        p = re.compile(N(a))
        hits += [(x['pos'], a) for x in S if p.search(N(x['text']))]
    if not hits: return None
    hits.sort(); cl, cur = [], [hits[0]]
    for h in hits[1:]:
        if h[0] - cur[-1][0] <= gap: cur.append(h)
        else: cl.append(cur); cur = [h]
    cl.append(cur)
    best = max(cl, key=lambda c: (len({a for _, a in c}), len(c)))
    return best[0][0] - pad, best[-1][0] + pad

def regions(T, table):
    """{case: (pids, [(vol, lo, hi)])} for volumes present in T."""
    byvol = collections.defaultdict(list)
    for x in T: byvol[x['vol']].append(x)
    out = {}
    for k, (pids, locs) in table.items():
        rs = []
        for vol, an in locs:
            if vol in byvol:
                r = anchor_region(byvol[vol], an)
                if r: rs.append((vol, r[0], r[1]))
        out[k] = (pids, rs)
    return out

def hit_v3(member, F, pids, rs, disc_level=False):
    f = F[member['pi']]
    key = f"{f['vol']}.{f['disc']}" if disc_level else f['pid']
    if key not in pids: return False
    return any(member['vol'] == v and member['lo'] <= hi and member['hi'] >= lo for v, lo, hi in rs)

def hit_v2run(run, pids, rs):
    return any(p['pid'] in pids and any(run['src'] == v and lo <= p['tpos'] <= hi for v, lo, hi in rs) for p in run['pairs'])

def first_rank(ranked, test):
    for n, x in enumerate(ranked, 1):
        if test(x): return n
    return None

# ---------------------------------------------------------------- judged packets (for new/judged flags)
def judged_packets(root=C.ROOT):
    """Packets from earlier rounds: id, label, Feijoo pids, Trévoux volume, aligned French sentences."""
    verdicts = {}
    for p in glob.glob(f'{root}/out/verdicts/*.json'):
        try: v = json.load(open(p)); verdicts[os.path.basename(p)[:-5]] = v.get('label')
        except Exception: pass
    out = []
    for d, pre in [('packets_ia', ''), ('packets_v2', 'V2-'), ('packets_v2b', 'V2B-'), ('packets_jds', 'JDS-')]:
        for p in sorted(glob.glob(f'{root}/out/{d}/R*.md')):
            s = open(p).read(); pid = pre + os.path.basename(p)[:-3]
            h = re.match(r'# R\d+ score=\S+ n=\d+ TC(\d)\.(\S+) .*?/ (?:Trévoux|JdS)? ?(\S+) pos (\d+)-(\d+)', s)
            if not h: continue
            vol, disc, src = h.group(1), h.group(2), h.group(3)
            paras = re.findall(r'\[TC(\d)\.(\S+) ¶seq(\d+)', s)
            fr = re.findall(r'^  FR: (.*)$', s, re.M)
            out.append({'id': pid, 'label': verdicts.get(pid), 'src': src,
                        'pids': {f'{a}.{b}.{c}' for a, b, c in paras}, 'fr': fr})
    return out

def locate(S_vol, text):
    """Best-matching sentence position for a French snippet (word-set overlap on the ſ/f-folded text)."""
    q = set(re.findall(r'[a-zS]{4,}', N(text)))
    if not q: return None
    best, bp = 0, None
    for x in S_vol:
        w = x.setdefault('_w', set(re.findall(r'[a-zS]{4,}', N(x['text']))))
        o = len(q & w) / (len(q) ** 0.5 * max(len(w), 1) ** 0.5)
        if o > best: best, bp = o, x['pos']
    return bp if best > 0.35 else None

def judged_regions(T, packets):
    byvol = collections.defaultdict(list)
    for x in T: byvol[x['vol']].append(x)
    for pk in packets:
        S = byvol.get(pk['src'])
        pos = [p for p in (locate(S, f) for f in pk['fr']) if p is not None] if S else []
        pk['region'] = (min(pos) - 15, max(pos) + 15) if pos else None
    return packets
