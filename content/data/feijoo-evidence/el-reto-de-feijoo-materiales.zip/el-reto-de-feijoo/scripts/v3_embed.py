#!/usr/bin/env python3
"""LaBSE sentence embeddings on CPU with a per-volume cache (data/cache/v3/emb/<fmt>/<vol>.<hash>.npy, float16).
usage: v3_embed.py FMT [VOL ...] [--shard i/n] [--threads 6]      (FMT = ia|kraken|bsb|jds|feijoo)
Never touches CUDA: CUDA_VISIBLE_DEVICES is forced empty before torch is imported."""
import os, sys, hashlib, time, argparse
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
import v3_corpus as C

CACHE = f'{C.ROOT}/data/cache/v3/emb'
_model = None

def model(threads=6):
    global _model
    if _model is None:
        import torch
        torch.set_num_threads(threads)
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer('sentence-transformers/LaBSE', device='cpu')
    return _model

def key(texts): return hashlib.md5('\n'.join(texts).encode()).hexdigest()[:10]

def embed(texts, fmt, name, threads=6, compute=True):
    """Cached normalized embeddings (float32 in memory). Returns None if missing and compute=False."""
    d = f'{CACHE}/{fmt}'; os.makedirs(d, exist_ok=True)
    p = f'{d}/{name}.{key(texts)}.npy'
    if os.path.exists(p): return np.load(p).astype(np.float32)
    if not compute: return None
    import torch
    with torch.inference_mode():
        e = model(threads).encode(texts, batch_size=32, normalize_embeddings=True, show_progress_bar=False)
    np.save(p + '.tmp.npy', e.astype(np.float16)); os.replace(p + '.tmp.npy', p)
    return e.astype(np.float32)

def feijoo_texts(F):
    """Feijoo units embedded: every sentence + 2-sentence windows inside a paragraph."""
    sents = [s for x in F for s in x['sents']]
    wins = [a + ' ' + b for x in F for a, b in zip(x['sents'], x['sents'][1:])]
    return sents, wins

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('fmt'); ap.add_argument('vols', nargs='*')
    ap.add_argument('--shard', default='0/1'); ap.add_argument('--threads', type=int, default=6)
    a = ap.parse_args()
    if a.fmt == 'feijoo':
        s, w = feijoo_texts(C.feijoo_segments())
        embed(s, 'feijoo', 'sents', a.threads)   # windows = normalised sums (no second pass)
        sys.exit()
    i, n = map(int, a.shard.split('/'))
    vols = (a.vols or C.list_volumes(a.fmt))[i::n]
    for v in vols:
        t = time.time(); S = C.LOADERS[a.fmt](v)
        had = embed([x['text'] for x in S], a.fmt, v, compute=False) is not None
        embed([x['text'] for x in S], a.fmt, v, a.threads)
        print(f'{a.fmt} {v}: {len(S)} sents {"cached" if had else f"{time.time() - t:.0f}s"}', flush=True)
