#!/usr/bin/env python3
"""CER/WER vs gt/*.txt. Hypotheses: pages/<stem>.<engine>.txt"""
import re, sys, glob, os, unicodedata, json
MONTHS = r'(Janvier|F[eé]vrier|Mars|Avril|May|Mai|Juin|Juillet|Ao[uû]st|Aoust|Septembre|Octobre|Novembre|D[eé]cembre)'
LIG = {'ﬁ':'fi','ﬂ':'fl','ﬀ':'ff','ﬃ':'ffi','ﬄ':'ffl','ﬅ':'st','ﬆ':'st','æ':'ae','Æ':'AE','œ':'oe','Œ':'OE','’':"'",'‘':"'",'ʼ':"'",'´':"'",'`':"'",'“':'"','”':'"','«':'"','»':'"','—':'-','–':'-','¬':'-'}
def clean_markup(t):
    t = re.sub(r'<[^>]+>', ' ', t)                     # html tags
    t = re.sub(r'!\[[^\]]*\]\([^)]*\)', ' ', t)        # md images
    t = re.sub(r'^\s{0,3}#+\s*', '', t, flags=re.M)
    t = t.replace('**', '').replace('__', '')
    t = re.sub(r'(?<![\w])[*_]([^*_\n]+)[*_](?![\w])', r'\1', t)
    t = re.sub(r'\\([&*_#])', r'\1', t)
    return t
def strip_furniture(lines):
    lines = [l for l in lines if l.strip()]
    if lines and re.search(r'(M[eé]m[oi0]ires|Sciences|beaux\s*Arts|Hi[sſf][tl]oire)', lines[0]) and len(lines[0]) < 60:
        lines = lines[1:]
    while lines and (re.search(MONTHS + r'\s*[1I]\s*[7J]', lines[-1]) or len(re.sub(r'\W', '', lines[-1])) <= 5):
        lines = lines[:-1]
    return lines
def norm(t, fold=False, furniture=True):
    t = unicodedata.normalize('NFC', clean_markup(t))
    for a, b in LIG.items(): t = t.replace(a, b)
    t = t.replace('ſ', 's')
    lines = [l.strip() for l in t.split('\n')]
    lines = [l for l in lines if l]
    out = ''
    for l in lines:
        if out.endswith('-') and l: out = out[:-1] + l
        else: out = (out + ' ' + l) if out else l
    t = re.sub(r'\s+', ' ', out)
    t = re.sub(r'(\w)[-¬] (?=[a-zà-ÿſ])', r'\1', t)
    t = re.sub(r'\s+([,.;:!?)])', r'\1', t); t = re.sub(r'([(])\s+', r'\1', t)
    t = re.sub(r"'\s+", "'", t)
    if fold: t = t.replace('f', 's')
    return t.strip()
def lev(h, g):
    # semi-global: gt must be fully matched, extra hyp text at either end (running heads, footers) is free
    prev = [0] * (len(h) + 1)
    for i, cg in enumerate(g, 1):
        cur = [i]
        for j, ch in enumerate(h, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (cg != ch)))
        prev = cur
    return min(prev)
def scores(hyp, gt):
    r = {}
    for k, fold in (('cer', False), ('cer_fs', True)):
        g, h = norm(gt, fold, False), norm(hyp, fold)
        r[k] = lev(h, g) / len(g)
    g, h = norm(gt, False, False).split(), norm(hyp).split()
    r['wer'] = lev(h, g) / len(g)
    return r
if __name__ == '__main__':
    engines = sorted({os.path.basename(p).split('.')[1] for p in glob.glob('pages/*.*.txt')})
    gts = sorted(glob.glob('gt/*.txt'))
    res = {}
    for e in engines:
        rows = []
        for g in gts:
            stem = os.path.basename(g)[:-4]; h = f'pages/{stem}.{e}.txt'
            if os.path.exists(h): rows.append(scores(open(h).read(), open(g).read()))
        if rows: res[e] = {k: sum(r[k] for r in rows) / len(rows) for k in rows[0]} | {'n': len(rows), 'per_page': [round(r['cer'], 4) for r in rows]}
    for e, r in sorted(res.items(), key=lambda x: x[1]['cer']):
        print(f"{e:22s} n={r['n']} CER={r['cer']*100:5.2f}%  CER(f=s)={r['cer_fs']*100:5.2f}%  WER={r['wer']*100:5.2f}%  {r['per_page']}")
    json.dump(res, open('scores.json', 'w'), indent=1)
