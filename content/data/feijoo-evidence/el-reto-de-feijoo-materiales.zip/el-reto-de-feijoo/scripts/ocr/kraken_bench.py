#!/usr/bin/env python3
"""Time kraken blla segmentation + PP-OCRv6 recognition per page. usage: kraken_bench.py MODEL DEVICE THREADS BATCH img..."""
import sys, time, torch, os
from pathlib import Path
from PIL import Image
from kraken.tasks import SegmentationTaskModel, RecognitionTaskModel
from kraken.configs import SegmentationInferenceConfig, RecognitionInferenceConfig
import kraken
from kraken.ketos.util import to_ptl_device
mpath, dev, th, bs, imgs = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), sys.argv[5:]
torch.set_num_threads(th)
torch.backends.cudnn.enabled = os.environ.get("MIOPEN", "0") == "1"  # MIOpen convs fail on gfx1151
seg = SegmentationTaskModel.load_model(Path(kraken.__file__).parent / 'blla.mlmodel')
rec = RecognitionTaskModel.load_model(Path(mpath))
acc, devs = to_ptl_device(dev)
P = os.environ.get('PREC', '32-true')
scfg = SegmentationInferenceConfig(accelerator=acc, device=devs, num_threads=th, precision=P)
rcfg = RecognitionInferenceConfig(accelerator=acc, device=devs, num_threads=th, batch_size=bs, precision=P)
for p in imgs:
    im = Image.open(p)
    t0 = time.time(); s = seg.predict(im=im, config=scfg); t1 = time.time()
    lines = [r.prediction for r in rec.predict(im=im, segmentation=s, config=rcfg)]; t2 = time.time()
    print(f'{Path(p).stem} lines={len(lines)} seg={t1-t0:.1f}s rec={t2-t1:.1f}s', flush=True)
