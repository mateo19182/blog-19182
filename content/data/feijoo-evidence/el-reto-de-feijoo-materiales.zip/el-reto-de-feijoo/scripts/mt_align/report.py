#!/usr/bin/env python3
"""Merge per-volume MT-alignment passages → validation on known cases + out/mt_align_candidates_ia.tsv.
usage: report.py [--min-score S] [--sources ia,bsb,jds,kraken]"""
import os, sys, json, glob, re, argparse, collections
sys.path.insert(0, os.path.dirname(__file__))
from fr_norm import ROOT, CACHE

VOLDIR = os.path.join(CACHE, 'vol')
KRAKEN_DIR = os.environ.get('FEIJOO_OCR_DIR', os.path.join(ROOT, 'data/trevoux/ocr'))
OUT = os.path.join(ROOT, 'out/mt_align_candidates_ia.tsv')
MIN_COS, MIN_SHARED = 0.10, 3   # candidate filter (drops sparse-window artefacts)

# known cases: Feijoo para labels (filosofia) × Trévoux IA volume(s); pos = counts as true reuse for recall
GOLD = {
    'C001': ('pos', {'t214pt20', 't214pt21', 't214pt22', 't214pt23'}, {'memoirespourlhis1716unse', 'bsb10539854'}),
    'C002': ('pos', {'t214pt39', 't214pt40', 't214pt41', 't214pt42'}, {'memoirespourlhis1707unse'}),
    'C003': ('pos', {'t116pt122'}, {'memoirespourlhi1704unse_2'}),
    'C004': ('pos', {'t202pt75', 't202pt76'}, {'memoirespourlhi1715unse_1'}),
    'C005': ('pos', {'t105pt15', 't105pt16', 't105pt17'}, {'memoirespourlhi1710unse_2'}),
    'C006': ('neg', {'t310pt10', 't106pt10'}, {'memoirespourlhi1702unse_0'}),
    'C007': ('pos', {'t116pt143', 't116pt146'}, {'memoirespourlhi1706unse_0'}),
    'C008': ('neg', {'t307pt26', 't307pt27'}, {'memoirespourlhis1713unse', 'memoirespourlhi1705unse_0'}),
    'C009': ('pos', {'t114pt02'}, {'memoirespourlhi1716unse_0'}),
    'C010': ('pos', {'t112pt08'}, {'memoirespourlhi1701unse_1', 'memoirespourlhi1702unse_2'}),
    'C011': ('pos', {'t215pt15', 't215pt16', 't215pt17'}, {'jds1682_amsterdam'}),
    'C012': ('pos', {'t306pt03', 't306pt04', 't306pt05'}, {'memoirespourlhi1701unse_0', 'bsb10539793'}),
    'C013': ('neg', {'t310pt28'}, {'memoirespourlhi1701unse_2', 'memoirespourlhi1702unse_1', 'memoirespourlhis1704unse'}),
    'C014': ('neg', {f't305pt{i:02d}' for i in range(1, 40)}, {'memoirespourlhis1702unse'}),
    'C015': ('pos', {'t214pt03', 't214pt24', 't214pt25'}, {'memoirespourlhi1716unse_2'}),
    'C016': ('neg', {'t116pt76'}, {'memoirespourlhi1702unse_0'}),
    'V2-R003': ('pos', {'t2p8pt41'}, {'memoirespourlhi1709unse_0'}),
}

def base_src(s): return s.split(':', 1)[-1]

def load_passages(kinds):
    P = []
    for f in sorted(glob.glob(os.path.join(VOLDIR, '*.json'))):
        r = json.load(open(f))
        src = r['src']; k = 'kraken' if src.startswith('kraken:') else 'bsb' if src.startswith('bsb') else \
            'jds' if 'jds' in src else 'ia'
        if k not in kinds: continue
        if k == 'kraken' and not os.path.exists(os.path.join(KRAKEN_DIR, src.split(':', 1)[1] + '.done')):
            continue   # volume still being OCRed: its cached alignment may be partial
        for p in r['passages']:
            p['src'] = src; p['kind'] = k
            p['margin'] = p['score']
            p['score'] = round(p['margin'] + 2 * p['cos'] + 0.01 * p['sg_score'], 3)   # calibrated on the gold volumes
            p['pass'] = p['cos'] >= MIN_COS and p['nshared'] >= MIN_SHARED
            P.append(p)
    return P

def tcu_maps():
    seq2lab, lab2vd = {}, {}
    for l in open(os.path.join(ROOT, 'data/feijoo/tcu_1-3.jsonl')):
        r = json.loads(l)
        lab = r['para_label'] or f"seq{r['para_seq']}"
        seq2lab[(r['vol'], r['disc_num'], r['para_seq'])] = lab; lab2vd[lab] = (r['vol'], r['disc_num'])
    return seq2lab, lab2vd

def labse_found(seq2lab):
    """(src, para_label) pairs present in any LaBSE run file."""
    S = set()
    for f in glob.glob(os.path.join(ROOT, 'out/*.runs.jsonl')) + glob.glob(os.path.join(ROOT, 'out/full_ia_v2.*.jsonl')):
        for l in open(f):
            r = json.loads(l)
            for p in r['pairs']:
                lab = seq2lab.get((r['vol'], r['disc'], p['fpara']))
                if lab: S.add((r['src'], lab))
    return S

def judged():
    """verdict id → (src set, para label set, (vol, disc) or None, label)."""
    J = {}
    for f in glob.glob(os.path.join(ROOT, 'out/verdicts/*.json')):
        r = json.load(open(f))
        tl, fl = str(r.get('trevoux_loc', '')), str(r.get('feijoo_loc', ''))
        srcs = set(re.findall(r'memoirespourlhi\w+', tl)) or ({'jds1682_amsterdam'} if 'JdS' in tl else set())
        labs = set(re.findall(r't\d+p?t?\d*pt\d+[a-z]?\d*', fl)) | set(re.findall(r'seq\d+', fl))
        rng = re.findall(r't(\d{3})pt(\d{2})\s*[-–]\s*(?:t\d{3}pt)?(\d{2})', fl)
        for d, x, y in rng:
            labs |= {f't{d}pt{i:02d}' for i in range(int(x), int(y) + 1)}
        m = re.search(r'TC\s*(I{1,3}|[123])\s*\.\s*(\d+)', fl)
        vd = None
        if m:
            v = {'I': 1, 'II': 2, 'III': 3}.get(m.group(1), None) or int(m.group(1)); vd = (v, int(m.group(2)))
        J[os.path.basename(f)[:-5]] = (srcs, labs, vd, r.get('label'))
    return J

def group(P, lab2vd):
    """Merge passages of both streams / IA+BSB copies that point to the same Feijoo paras and the same Trévoux area."""
    P.sort(key=lambda p: -p['score'])
    G = []
    for p in P:
        ps = set(p['paras'])
        for g in G:
            if g['srcbase'] == p['srcbase_y'] and ps & g['paras'] and \
                    (p['kind'] != g['kind0'] or p['stream'] != g['streams'][0] or abs(_ln(p) - _ln(g['top'])) < 400):
                g['members'].append(p); g['paras'] |= ps; break
        else:
            G.append({'top': p, 'members': [p], 'paras': ps, 'srcbase': p['srcbase_y'], 'kind0': p['kind'],
                      'streams': [p['stream']]})
    return G

def _ln(p):
    m = re.search(r'\d+', p['loc0'] or '')
    return int(m.group()) if m else 0

YEAR = re.compile(r'(1[67]\d\d)')
def src_year(src, manifest):
    if src in manifest: return manifest[src]
    m = YEAR.search(src); return m.group(1) if m else ''

def latin_ids():
    """Segments that MT copied through unchanged (Latin quotations)."""
    L = set()
    for l in open(os.path.join(ROOT, 'data/feijoo/tcu_mt_fr.jsonl')):
        r = json.loads(l)
        es = re.findall(r'\w+', r['es'].lower()); fr = set(re.findall(r'\w+', r['fr'].lower()))
        if len(es) >= 4 and sum(w in fr for w in es) >= 0.6 * len(es): L.add(r['id'])
    return L

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--min-score', type=float, default=None)
    ap.add_argument('--sources', default='ia,bsb,jds,kraken')
    ap.add_argument('--out', default=OUT, help='TSV path (validation JSON goes next to it when not the default)')
    a = ap.parse_args()
    out = a.out
    P = load_passages(set(a.sources.split(',')))
    manifest = {}
    import csv
    for r in csv.DictReader(open(os.path.join(ROOT, 'data/trevoux/manifest.csv'))):
        manifest[r['identifier']] = r['year']
    for p in P:
        p['srcbase_y'] = src_year(base_src(p['src']), manifest) + ':' + ('trev' if p['kind'] != 'jds' else 'jds')
    LAT = latin_ids()
    for p in P:
        ids = p.get('seg_ids') or []
        p['latin'] = round(sum(i in LAT for i in ids) / len(ids), 2) if ids else 0
    seq2lab, lab2vd = tcu_maps()
    L = labse_found(seq2lab)
    J = judged()
    # ---- validation
    print('== validation (best passage per case; rank among all passages of that stream, by score)')
    by_stream = collections.defaultdict(list)
    for p in P:
        if p['pass']: by_stream[p['stream']].append(p['score'])
    for s in by_stream: by_stream[s].sort(reverse=True)
    val = {}
    for cid, (pol, labs, srcs) in GOLD.items():
        row = {}
        for st in ('fe1', 'fil'):
            cand = [p for p in P if p['stream'] == st and base_src(p['src']) in srcs and labs & set(p['paras'])]
            if cand:
                b = max(cand, key=lambda p: (p['pass'], p['score']))
                rank = 1 + sum(1 for x in by_stream[st] if x > b['score']) if b['pass'] else 'filtered'
                row[st] = (b['score'], b['sg_keys'], b['rho'], rank, b['loc0'], b['margin'], b['cos'])
            else:
                row[st] = None
        val[cid] = row
        f = lambda r: f"s={r[0]:.2f} m={r[5]:.2f} cos={r[6]:.2f} sg={r[1]} rank={r[3]} @{r[4]}" if r else '—'
        print(f"{cid:8s} {pol}  fil: {f(row['fil']):62s} fe1: {f(row['fe1'])}")
    json.dump(val, open(os.path.join(CACHE, 'validation.json') if out == OUT else out.rsplit('.', 1)[0] + '.validation.json', 'w'))
    # ---- candidates
    thr = a.min_score if a.min_score is not None else 0
    print('passages passing filter per stream:', {k: len(v) for k, v in by_stream.items()})
    G = group([p for p in P if p['pass'] and p['score'] >= thr], lab2vd)
    rows = []
    for g in G:
        t = g['top']
        mem = g['members']
        sc = {st: max([m['score'] for m in mem if m['stream'] == st], default=0) for st in ('fe1', 'fil')}
        srcs = sorted({m['src'] for m in mem})
        status = []
        for cid, (pol, labs, gs) in GOLD.items():
            if labs & g['paras'] and {base_src(s) for s in srcs} & gs: status.append(cid)
        for vid, (js, jl, vd, lab) in J.items():
            if not ({base_src(s) for s in srcs} & js): continue
            if (jl and jl & g['paras']) or (not jl and vd and any(lab2vd.get(x) == vd for x in g['paras'])):
                status.append(f'{vid}:{lab}')
        lab = any((base_src(s), x) in L for s in srcs for x in g['paras'])
        rows.append({'score': max(sc.values()), 'margin': t['margin'], 'score_fe1': sc['fe1'], 'score_fil': sc['fil'], 'cos': t['cos'], 'sg_keys': t['sg_keys'], 'sg_score': t['sg_score'],
                     'rho': t['rho'], 'nshared': t['nshared'], 'latin_quote': t['latin'], 'vol': t['vol'], 'disc': t['disc'], 'title': t['title'] or '',
                     'paras': ','.join(sorted(g['paras'])[:8]), 'scan_1st_ed': next((m['scan'] for m in mem if m.get('scan')), ''),
                     'src': ' '.join(srcs), 'loc': f"{t['loc0']}–{t['loc1']}",
                     'status': ' '.join(status) if status else 'new', 'labse_run': 'yes' if lab else 'no',
                     'stems': ' '.join(t['top_stems'][:12]),
                     'es': t['es'][:400].replace('\t', ' ').replace('\n', ' '),
                     'trev': re.sub(r'\s+', ' ', t['trev'])[:500].replace('\t', ' ')})
    rows.sort(key=lambda r: -r['score'])
    with open(out, 'w') as f:
        cols = list(rows[0].keys()) if rows else []
        f.write('rank\t' + '\t'.join(cols) + '\n')
        for i, r in enumerate(rows, 1):
            f.write(f'{i}\t' + '\t'.join(str(r[c]) for c in cols) + '\n')
    n_new = sum(r['status'] == 'new' for r in rows)
    print(f'{len(rows)} candidate groups (min score {thr}) → {out}; new: {n_new}; judged/case: {len(rows) - n_new}; '
          f'not in any LaBSE run: {sum(r["labse_run"] == "no" for r in rows)}')

if __name__ == '__main__':
    main()
