#!/usr/bin/env python3
"""Feijoo TCU I–III → sentence segments for MT.
Two streams:  fe1 = BNE first-edition OCR (1726/28/29), spelling-normalised (es_norm), mapped to filosofia paragraphs;
              fil = filosofia.org main text (1777–79; additions/later parts dropped), as a clean control.
Writes data/cache/mt_align/feijoo_segments.jsonl"""
import os, re, json, glob, math, collections, sys
sys.path.insert(0, os.path.dirname(__file__))
from es_norm import clean_page, norm_text, fold, ROOT

OUT = os.path.join(ROOT, 'data/cache/mt_align/feijoo_segments.jsonl')
SENT = re.compile(r'(?<=[.!?;:])\s+(?=[A-ZÁÉÍÓÚÑ¿¡«"(])')
MAXW = 60

def ok(s):
    w = s.split()
    return len(w) >= 4 and sum(c.isalpha() for c in s) >= 0.8 * len(s.replace(' ', '')) and \
        sum(len(x.strip('.,;:¿?¡!()«»"\'')) >= 3 and x.strip('.,;:¿?¡!()«»"\'').isalpha() for x in w) >= 0.5 * len(w)

def split_sents(t):
    t = re.sub(r'Biblioteca Nacional de España', ' ', t)
    out = []
    for s in SENT.split(t):
        s = s.strip()
        w = s.split()
        if len(w) > MAXW:  # MT models degrade on very long inputs: cut at commas near MAXW
            cur = []
            for tok in w:
                cur.append(tok)
                if len(cur) >= MAXW * 0.6 and tok.endswith(',') or len(cur) >= MAXW * 1.3:
                    out.append(' '.join(cur)); cur = []
            if cur: out.append(' '.join(cur))
        elif len(s) >= 20:
            out.append(s)
    return [s for s in out if ok(s)]

def fil_paras():
    for l in open(os.path.join(ROOT, 'data/feijoo/tcu_1-3.jsonl')):
        r = json.loads(l)
        if r['is_addition'] or r.get('later_part') or r.get('post_first_edition'): continue
        yield r

def fe1_paras(vol):
    """Concatenate numbered paragraphs across BNE openings; yields dicts with scan of first line."""
    cur = None
    for p in sorted(glob.glob(os.path.join(ROOT, f'data/feijoo/firsted_scans/{vol}/*.txt'))):
        scan = os.path.basename(p)[:-4]
        for n, t in clean_page(open(p, errors='replace').read()):
            if n is None and cur is not None:
                cur['text'] += ' ' + t; cur['scans'].append(scan)
            else:
                if cur: yield cur
                cur = {'num': n, 'text': t, 'scans': [scan]}
    if cur: yield cur

TOK = re.compile(r'[a-zñ]{5,}')

def main():
    fil = list(fil_paras())
    segs = []
    for r in fil:
        for k, s in enumerate(split_sents(r['text'])):
            segs.append({'id': f"fil:{r['vol']}:{r['disc_num']}:{r['kind'][:4]}:{r['para_label'] or r['para_seq']}:{k}", 'stream': 'fil', 'vol': r['vol'],
                         'disc': r['disc_num'], 'title': r['disc_title'], 'para': r['para_label'] or f"seq{r['para_seq']}",
                         'n': r['para_idx'], 'es': s})
    # index fil paragraphs for fe1 → para mapping
    df = collections.Counter()
    ftoks = []
    for r in fil:
        t = set(TOK.findall(fold(r['text']))); ftoks.append(t); df.update(t)
    inv = collections.defaultdict(list)
    for i, t in enumerate(ftoks):
        for w in t: inv[w].append(i)
    idf = {w: math.log(len(fil) / c) for w, c in df.items()}
    romans = {1: 'I', 2: 'II', 3: 'III'}
    for vol in (1, 2, 3):
        prev = None
        for k, p in enumerate(fe1_paras(romans[vol])):
            txt = norm_text(p['text'])
            toks = set(TOK.findall(fold(txt)))
            sc = collections.Counter()
            for w in toks:
                if w in inv and df[w] < 200:
                    for i in inv[w]:
                        if fil[i]['vol'] == vol: sc[i] += idf[w]
            best, bs = (sc.most_common(1) or [(None, 0)])[0]
            tot = sum(idf.get(w, 8) for w in toks) or 1
            m = fil[best] if best is not None and bs / tot > 0.25 else None
            for j, s in enumerate(split_sents(txt)):
                segs.append({'id': f"fe1:{vol}:{p['scans'][0]}:{k}:{j}", 'stream': 'fe1', 'vol': vol,
                             'disc': m and m['disc_num'], 'title': m and m['disc_title'],
                             'para': m and (m['para_label'] or f"seq{m['para_seq']}"), 'n': p['num'],
                             'scan': p['scans'][0], 'map': round(bs / tot, 2), 'es': s})
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, 'w') as f:
        for s in segs: f.write(json.dumps(s, ensure_ascii=False) + '\n')
    c = collections.Counter(s['stream'] for s in segs)
    mapped = sum(1 for s in segs if s['stream'] == 'fe1' and s['para'])
    print(dict(c), 'fe1 mapped to fil para:', mapped, 'words:',
          {k: sum(len(s['es'].split()) for s in segs if s['stream'] == k) for k in c}, file=sys.stderr)

if __name__ == '__main__':
    main()
