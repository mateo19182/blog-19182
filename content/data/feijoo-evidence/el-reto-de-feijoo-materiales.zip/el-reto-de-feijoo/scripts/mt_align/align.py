#!/usr/bin/env python3
"""Monolingual FR–FR passage alignment: Feijoo-MT (data/feijoo/tcu_mt_fr.jsonl) vs Trévoux OCR (TextPAIR-like).
Stage 1 (retrieval, the score): IDF-weighted bag-of-stems cosine between Feijoo windows (30 content tokens, step 10)
and Trévoux windows (60, step 20), turned into a ratio margin against both sides' 10 nearest neighbours in the volume.
Stage 2 (evidence): TextPAIR-like unordered skip-bigrams of stems (window W) + rare unigrams inside each passage box;
order coherence rho over those hits.

usage:
  align.py df                          build stem document-frequency table from all sources (once)
  align.py vol SRC [SRC...]            align volumes (SRC = path to IA .txt | BSB .jsonl | kraken .jsonl | JdS .txt)
  align.py all [--kraken] [--jobs N]   all IA+BSB (+kraken OCR dir) + JdS 1682; per-volume cache, skips up-to-date
Per-volume results: data/cache/mt_align/vol/<src_id>.json"""
import os, sys, json, re, math, glob, bisect, collections, argparse, hashlib, time
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.path.insert(0, os.path.dirname(__file__))
from fr_norm import content, CACHE, ROOT, MT

W = 4                  # skip-bigram window (content tokens)
RARE, UNI = 7.0, 0.5    # unigram hits: only stems with idf >= RARE, weight UNI*idf
MAXPOST = 25           # ignore pairs occurring more often than this in a Feijoo stream
KRAKEN = os.environ.get('FEIJOO_OCR_DIR', os.path.join(ROOT, 'data/trevoux/ocr'))
VOLDIR = os.path.join(CACHE, 'vol')
DF = os.path.join(CACHE, 'stem_df.json')
VERSION = 'v3'

# ---------- Trévoux readers: yield (loc, line) ----------
def read_src(path):
    b = os.path.basename(path)
    if path.endswith('.txt') and 'jds' in b:
        page = None
        for k, l in enumerate(open(path, errors='replace'), 1):
            m = re.match(r'=== p\. (\S+)', l)
            if m: page = m.group(1); continue
            yield f'p.{page} L{k}', l.rstrip('\n')
    elif path.endswith('.txt'):
        for k, l in enumerate(open(path, errors='replace'), 1):
            yield f'L{k}', l.rstrip('\n')
    else:
        for l in open(path):
            r = json.loads(l)
            if 'lines' in r:   # BSB API OCR
                for x in (r['lines'] or []): yield f"scan{r['scan']}", x
            else:              # kraken OCR, one leaf per record
                for x in (r.get('text') or '').splitlines(): yield f"leaf{r['leaf']}", x

def src_id(path):
    b = os.path.basename(path).rsplit('.', 1)[0]
    return ('kraken:' if path.startswith(KRAKEN) else '') + b

def load_text(path):
    """Dehyphenated text + per-char loc lookup."""
    parts, starts, locs, n = [], [], [], 0
    prev_h = False
    for loc, l in read_src(path):
        l = l.strip()
        if not l: continue
        h = l.endswith(('-', '¬'))
        if h: l = l[:-1]
        sep = '' if prev_h else ' '
        starts.append(n + len(sep)); locs.append(loc)
        parts.append(sep + l); n += len(sep) + len(l); prev_h = h
    return ''.join(parts), starts, locs

# ---------- Feijoo side ----------
_F = None
def feijoo():
    """Per stream: token stems, token→record index; merged pair index key → [(stream, pos)]."""
    global _F
    if _F: return _F
    recs = [json.loads(l) for l in open(MT)]
    order = {json.loads(l)['id']: i for i, l in enumerate(open(os.path.join(CACHE, 'feijoo_segments.jsonl')))}
    recs.sort(key=lambda r: order.get(r['id'], 1 << 30))   # original text order
    streams = {}
    for i, r in enumerate(recs):
        st = streams.setdefault(r['stream'], {'stems': [], 'rec': []})
        for s, _ in content(r['fr']):
            st['stems'].append(s); st['rec'].append(i)
    idx = collections.defaultdict(list)
    for sname, st in streams.items():
        S = st['stems']
        for p in range(len(S)):
            idx['=' + S[p]].append((sname, p))    # unigram key; used only for rare stems
            for k in range(1, W + 1):
                if p + k < len(S) and S[p] != S[p + k]:
                    a, b = sorted((S[p], S[p + k]))
                    idx[a + ' ' + b].append((sname, p))
    idx = {k: v for k, v in idx.items() if len(v) <= 2 * MAXPOST}
    _F = recs, streams, idx
    return _F

def idf_table():
    d = json.load(open(DF))
    N = d['N']
    return {s: math.log(N / (c + 1)) for s, c in d['df'].items()}, math.log(N)

# ---------- stage 1: bag-of-stems window retrieval with margin (Artetxe–Schwenk style, per volume) ----------
FW, FS, TW, TS = 30, 10, 60, 20   # window/step in content tokens: Feijoo (≈65 words) / Trévoux (≈130 words)
MINIDF = 4.0                       # stems below this IDF are ignored in window vectors
KNN = 10
SMOOTH = float(os.environ.get('SMOOTH', 40))   # added to window IDF mass: damps sparse windows
M_KEEP = float(os.environ.get('M_KEEP', 1.6))   # keep cells with margin >= this
TOPN = 200                         # max cells kept per volume and stream

_FM = {}
def feijoo_windows(sname):
    """Sparse Feijoo window matrix (binary) + window starts; vocabulary = stems with idf >= MINIDF."""
    if sname in _FM: return _FM[sname]
    import numpy as np, scipy.sparse as sp
    recs, streams, _ = feijoo(); idf, imax = idf_table()
    S = streams[sname]['stems']
    voc = _FM.setdefault('_voc', {})
    rows, cols = [], []
    starts = list(range(0, max(len(S) - FW // 2, 1), FS))
    for r, s0 in enumerate(starts):
        for s in set(S[s0:s0 + FW]):
            if idf.get(s, imax) >= MINIDF:
                rows.append(r); cols.append(voc.setdefault(s, len(voc)))
    _FM[sname] = (rows, cols, starts)
    return _FM[sname]

def window_margins(sname, T, idf, imax):
    import numpy as np, scipy.sparse as sp
    rows, cols, fstarts = feijoo_windows(sname)
    voc = _FM['_voc']
    V = len(voc) + 1
    F = sp.csr_matrix((np.ones(len(rows), np.float32), (rows, cols)), shape=(len(fstarts), V))
    fw = np.zeros(V, np.float32)
    for s, k in voc.items(): fw[k] = idf.get(s, imax)
    fn = np.asarray(F @ fw).ravel() + SMOOTH
    tstarts = list(range(0, max(len(T) - TW // 2, 1), TS))
    tr, tc, tv, tn = [], [], [], np.full(len(tstarts), SMOOTH, np.float32)
    for r, j0 in enumerate(tstarts):
        for s in set(T[j0:j0 + TW]):
            w = idf.get(s, imax)
            if w < MINIDF: continue
            tn[r] += w
            k = voc.get(s)
            if k is not None: tr.append(r); tc.append(k); tv.append(w)
    Tm = sp.csr_matrix((np.array(tv, np.float32), (tr, tc)), shape=(len(tstarts), V))
    C = (F @ Tm.T).toarray().astype(np.float32)
    C /= np.sqrt(fn[:, None] * tn[None, :])
    k = min(KNN, C.shape[1] - 1, C.shape[0] - 1)
    if k < 1: return None
    rk = -np.partition(-C, k, axis=1)[:, :k].mean(1)
    ck = -np.partition(-C, k, axis=0)[:k, :].mean(0)
    Mg = C / ((rk[:, None] + ck[None, :]) / 2 + 1e-6)
    return Mg, C, fstarts, tstarts

# ---------- alignment of one volume ----------
def align_volume(path):
    import numpy as np
    t0 = time.time()
    recs, streams, idx = feijoo()
    idf, idf_max = idf_table()
    text, starts, locs = load_text(path)
    toks = content(text)
    T = [s for s, _ in toks]
    tl = [bisect.bisect_right(starts, o) - 1 for _, o in toks]   # token → line index
    out = []
    if len(T) >= 2 * TW:
        # stage 2 evidence: skip-bigram (+ rare unigram) hits, TextPAIR-like
        hits = collections.defaultdict(list)   # stream → list of (fpos, tpos, key, w)
        for j in range(len(T)):
            wu = idf.get(T[j], idf_max)
            if wu >= RARE:
                post = idx.get('=' + T[j])
                if post:
                    for sname, p in post: hits[sname].append((p, j, '=' + T[j], UNI * wu))
            for k in range(1, W + 1):
                if j + k >= len(T) or T[j] == T[j + k]: continue
                a, b = sorted((T[j], T[j + k]))
                post = idx.get(a + ' ' + b)
                if not post: continue
                w = min(idf.get(a, idf_max), idf.get(b, idf_max))
                if w < 3.0: continue
                for sname, p in post: hits[sname].append((p, j, a + ' ' + b, w))
        for sname in streams:
            wm = window_margins(sname, T, idf, idf_max)
            if wm is None: continue
            Mg, C, fstarts, tstarts = wm
            cand = np.argwhere(Mg >= M_KEEP)
            if len(cand) > TOPN * 4:
                v = Mg[cand[:, 0], cand[:, 1]]; cand = cand[np.argsort(-v)[:TOPN * 4]]
            # group neighbouring cells (≤3 windows apart on both axes) into passages
            cand = sorted(map(tuple, cand), key=lambda c: -Mg[c])
            groups = []
            for i, j in cand:
                for g in groups:
                    if any(abs(i - a) <= 3 and abs(j - b) <= 3 for a, b in g): g.append((i, j)); break
                else: groups.append([(i, j)])
            groups = groups[:TOPN]
            H = hits.get(sname, [])
            HP = np.fromiter((h[0] for h in H), np.int64, len(H)); HJ = np.fromiter((h[1] for h in H), np.int64, len(H))
            st = streams[sname]
            for g in groups:
                bi, bj = g[0]
                f0 = min(fstarts[a] for a, _ in g); f1 = max(fstarts[a] for a, _ in g) + FW
                t0_ = min(tstarts[b] for _, b in g); t1 = max(tstarts[b] for _, b in g) + TW
                f1 = min(f1, len(st['rec'])); t1 = min(t1, len(T))
                inb = [H[i] for i in np.nonzero((HP >= f0) & (HP < f1) & (HJ >= t0_) & (HJ < t1))[0]]
                best = {}
                for p, j, key, w in inb:
                    if key not in best or best[key][3] < w: best[key] = (p, j, key, w)
                sel = list(best.values())
                rho = spearman([h[0] for h in sel], [h[1] for h in sel])
                # shared rare stems in the best cell
                fs0, ts0 = fstarts[bi], tstarts[bj]
                shared = set(st['stems'][fs0:fs0 + FW]) & set(T[ts0:ts0 + TW])
                shared = sorted((s for s in shared if idf.get(s, idf_max) >= MINIDF), key=lambda s: -idf.get(s, idf_max))
                ri = sorted(set(st['rec'][p] for p in range(fs0, min(fs0 + FW, len(st['rec'])))))
                fr_recs = [recs[i] for i in ri]
                allri = sorted(set(st['rec'][p] for p in range(f0, f1)))
                l0, l1 = tl[ts0], tl[min(ts0 + TW, len(tl)) - 1]
                out.append({
                    'stream': sname, 'score': round(float(Mg[bi, bj]), 3), 'cos': round(float(C[bi, bj]), 3),
                    'ncells': len(g), 'sg_score': round(sum(h[3] for h in sel), 1), 'sg_keys': len(sel),
                    'rho': round(rho, 2), 'nshared': len(shared),
                    'vol': fr_recs[0]['vol'] if fr_recs else None,
                    'paras': sorted({recs[i]['para'] for i in allri if recs[i].get('para')}, key=str),
                    'best_paras': sorted({r['para'] for r in fr_recs if r.get('para')}, key=str),
                    'disc': fr_recs[0].get('disc') if fr_recs else None,
                    'title': fr_recs[0].get('title') if fr_recs else None,
                    'seg_ids': [r['id'] for r in fr_recs][:20],
                    'scan': fr_recs[0].get('scan') if fr_recs else None,
                    'loc0': locs[l0], 'loc1': locs[l1],
                    'tloc_span': [locs[tl[t0_]], locs[tl[t1 - 1]]],
                    'top_stems': shared[:20],
                    'es': ' '.join(r['es'] for r in fr_recs)[:1500],
                    'fr_mt': ' '.join(r['fr'] for r in fr_recs)[:1500],
                    'trev': text[starts[l0]:starts[min(l1 + 1, len(starts) - 1)]][:2000],
                })
    out.sort(key=lambda r: -r['score'])
    res = {'src': src_id(path), 'path': path, 'version': VERSION, 'mt_sig': mt_sig(), 'n_tokens': len(T),
           'secs': round(time.time() - t0, 1), 'passages': out}
    os.makedirs(VOLDIR, exist_ok=True)
    json.dump(res, open(os.path.join(VOLDIR, res['src'].replace(':', '__') + '.json'), 'w'), ensure_ascii=False)
    return res['src'], len(out), res['secs']


def spearman(x, y):
    n = len(x)
    if n < 3: return 0.0
    rk = lambda v: {i: r for r, i in enumerate(sorted(range(n), key=lambda i: v[i]))}
    rx, ry = rk(x), rk(y)
    d2 = sum((rx[i] - ry[i]) ** 2 for i in range(n))
    return 1 - 6 * d2 / (n * (n * n - 1))

_sig = None
def mt_sig():
    global _sig
    if _sig is None:
        st = os.stat(MT); _sig = f'{st.st_size}'
    return _sig

def all_sources(kraken=False):
    ps = sorted(glob.glob(os.path.join(ROOT, 'data/trevoux/ia/*.txt')))
    ps += sorted(glob.glob(os.path.join(ROOT, 'data/trevoux/bsb/*.jsonl')))
    ps += [os.path.join(ROOT, 'data/jds/jds1682_amsterdam.txt')]
    if kraken: ps += sorted(glob.glob(os.path.join(KRAKEN, '*.jsonl')))
    return ps

def build_df():
    df, N = collections.Counter(), 0
    for p in all_sources():
        text, _, _ = load_text(p)
        toks = [s for s, _ in content(text)]
        for i in range(0, len(toks), 200):    # "documents" = 200-token blocks
            df.update(set(toks[i:i + 200])); N += 1
        print(p, len(toks), file=sys.stderr)
    json.dump({'N': N, 'df': {k: v for k, v in df.items() if v >= 2}}, open(DF, 'w'))

def up_to_date(path):
    f = os.path.join(VOLDIR, src_id(path).replace(':', '__') + '.json')
    if not os.path.exists(f): return False
    if os.path.getmtime(f) < os.path.getmtime(path): return False
    try:
        r = json.load(open(f))
        return r.get('version') == VERSION and r.get('mt_sig') == mt_sig()
    except Exception:
        return False

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd'); ap.add_argument('srcs', nargs='*')
    ap.add_argument('--kraken', action='store_true'); ap.add_argument('--jobs', type=int, default=6)
    ap.add_argument('--force', action='store_true')
    a = ap.parse_args()
    if a.cmd == 'df':
        build_df(); sys.exit()
    paths = a.srcs if a.cmd == 'vol' else all_sources(a.kraken)
    if not a.force: paths = [p for p in paths if not up_to_date(p)]
    print(len(paths), 'volumes to align', file=sys.stderr)
    for sname in feijoo()[1]: feijoo_windows(sname)   # build once, share with forked workers
    if a.jobs > 1 and len(paths) > 1:
        import multiprocessing as mp
        with mp.get_context('fork').Pool(min(a.jobs, 10)) as pool:
            for r in pool.imap_unordered(align_volume, paths): print(*r, file=sys.stderr, flush=True)
    else:
        for p in paths: print(*align_volume(p), file=sys.stderr, flush=True)
