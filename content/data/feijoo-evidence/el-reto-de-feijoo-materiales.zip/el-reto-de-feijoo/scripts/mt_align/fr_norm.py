"""French normalisation shared by MT output (modern) and Trévoux OCR (1701–1729): ſ/f, oi→ai, y→i, -ez, accents,
stopwords, Snowball stem. Old forms are pulled toward the MT-French vocabulary (the only words that can match)."""
import re, os, json, unicodedata, functools, collections
import Stemmer

ROOT = os.path.join(os.path.dirname(__file__), '..', '..')
CACHE = os.path.join(ROOT, 'data/cache/mt_align')
MT = os.path.join(ROOT, 'data/feijoo/tcu_mt_fr.jsonl')
WORD = re.compile(r"[A-Za-zÀ-ÿſœæŒÆ]+")
_stem = Stemmer.Stemmer('french')

def fold(s):
    s = s.lower().replace('ſ', 's').replace('œ', 'oe').replace('æ', 'ae')
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')

STOP = set(fold(w) for w in """
a à au aux avec ce ces cet cette c ceux celle celles celui ci comme d dans de des du elle elles en et eux il ils je j l la
le les leur leurs lui m ma mais me même mêmes mes moi mon n ne ni nos notre nous on ou où par pas pour qu que qui s sa
sans se ses si son sont sur t ta te tes toi ton tu un une vos votre vous y été être est était étaient sont fut furent
ont a avait avaient avoit avoient eut ai as avons avez fait faire font dit plus moins tout tous toute toutes très bien
aussi autre autres peu peut peuvent point quelque quelques car donc or ainsi alors après avant cela ceci dont lors
leurs mesme meme tant tel telle tels telles quand quoi sous entre encore même non oui fort celui-ci là ici
puis sera seront soit soient serait seraient avoir ete etoit estoit sieur mr m. monsieur dom pere p
""".split())

@functools.lru_cache(1)
def mt_vocab():
    v = collections.Counter()
    if os.path.exists(MT):
        for l in open(MT):
            v.update(fold(w) for w in WORD.findall(json.loads(l)['fr']))
    return v

# (old, new) rewrites on folded Trévoux words; tried singly, then pairs
RULES = [('oi', 'ai'), ('f', 's'), ('y', 'i'), ('i', 'y'), ('ez', 'es'), ('x', 's'), ('ay', 'ai'), ('tems', 'temps'),
         ('sc', 's'), ('st', 't'), ('sm', 'm'), ('sl', 'l'), ('sn', 'n'), ('sq', 'q'), ('sp', 'p'), ('sb', 'b'),
         ('sd', 'd'), ('ll', 'l'), ('tt', 't'), ('pp', 'p'), ('mm', 'm'), ('nn', 'n'), ('ff', 'f'), ('ss', 's'),
         ('ph', 'f'), ('th', 't'), ('u', 'v'), ('v', 'u'), ('ie', 'y'), ('oy', 'oi'), ('ai', 'e'), ('e', 'ee'),
         ('d', 'st'), ('ft', 'st'), ('fl', 'st'), ('li', 'st'), ('fi', 'st'), ('ll', 'st')]  # last row: OCR of long-s ligatures

def _subs(w):
    for a, b in RULES:
        i = w.find(a)
        while i >= 0:
            yield w[:i] + b + w[i + len(a):]
            i = w.find(a, i + 1)

@functools.lru_cache(500000)
def norm_word(w):
    """Folded, modernised form (not stemmed)."""
    lw = fold(w)
    voc = mt_vocab()
    if not voc or lw in voc or len(lw) < 3: return lw
    best, bn = lw, 0
    c1 = list(_subs(lw))
    for c in c1:
        if voc.get(c, 0) > bn: best, bn = c, voc[c]
    if bn == 0:
        for c in c1[:60]:
            for d in _subs(c):
                if voc.get(d, 0) > bn: best, bn = d, voc[d]
    return best

@functools.lru_cache(500000)
def stem(w):
    return re.sub(r'(.)\1+', r'\1', _stem.stemWord(w))   # collapse doubled letters (Commanville = Comanville)

def content(text):
    """→ list of (stem, char_offset) for content words."""
    out = []
    for m in WORD.finditer(text):
        n = norm_word(m.group())
        if len(n) < 3 or n in STOP: continue
        s = stem(n)
        if s in STOP or len(s) < 3: continue
        out.append((s, m.start()))
    return out
