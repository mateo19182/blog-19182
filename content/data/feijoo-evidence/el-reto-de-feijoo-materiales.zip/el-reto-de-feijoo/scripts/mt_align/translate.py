#!/usr/bin/env python3
"""ES→FR MT of Feijoo segments with Helsinki-NLP/opus-mt-es-fr (CTranslate2 int8, CPU only).
Resumable: appends to data/feijoo/tcu_mt_fr.jsonl, skipping ids already there.
usage: CUDA_VISIBLE_DEVICES= nice -n 19 translate.py [--limit N] [--threads 10]"""
import os, sys, json, time, argparse
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.path.insert(0, os.path.dirname(__file__))
from es_norm import ROOT
import ctranslate2, sentencepiece as spm

MODEL = os.path.join(ROOT, 'data/cache/mt_align/opus-mt-es-fr-ct2')
SEGS = os.path.join(ROOT, 'data/cache/mt_align/feijoo_segments.jsonl')
OUT = os.path.join(ROOT, 'data/feijoo/tcu_mt_fr.jsonl')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--threads', type=int, default=10)
    ap.add_argument('--batch', type=int, default=32)
    a = ap.parse_args()
    # cache keyed by source text: segment ids may change when feijoo_prep.py is re-run
    cache = {}
    if os.path.exists(OUT):
        for l in open(OUT):
            r = json.loads(l); cache[r['es']] = r['fr']
    segs = list(map(json.loads, open(SEGS)))
    ids = {s['id'] for s in segs}
    assert len(ids) == len(segs), 'duplicate segment ids'
    with open(OUT + '.tmp', 'w') as f:   # rewrite in current segment order, keeping cached translations
        for s in segs:
            if s['es'] in cache: f.write(json.dumps({**s, 'fr': cache[s['es']]}, ensure_ascii=False) + '\n')
    os.replace(OUT + '.tmp', OUT)
    todo = [s for s in segs if s['es'] not in cache]
    if a.limit: todo = todo[:a.limit]
    print(len(segs) - len(todo), 'cached;', len(todo), 'to translate', file=sys.stderr)
    if not todo: return
    tr = ctranslate2.Translator(MODEL, device='cpu', compute_type='int8', inter_threads=2,
                                intra_threads=max(1, a.threads // 2))
    sp_src = spm.SentencePieceProcessor(os.path.join(MODEL, 'source.spm'))
    sp_tgt = spm.SentencePieceProcessor(os.path.join(MODEL, 'target.spm'))
    todo.sort(key=lambda s: len(s['es']))  # length-bucketed batches
    t0, n = time.time(), 0
    with open(OUT, 'a') as f:
        for i in range(0, len(todo), 256):
            chunk = todo[i:i + 256]
            src = [sp_src.encode(s['es'], out_type=str)[:400] + ['</s>'] for s in chunk]
            res = tr.translate_batch(src, max_batch_size=a.batch, beam_size=2, max_decoding_length=512,
                                     repetition_penalty=1.1)
            for s, r in zip(chunk, res):
                fr = sp_tgt.decode([t for t in r.hypotheses[0] if t != '</s>'])
                f.write(json.dumps({**s, 'fr': fr}, ensure_ascii=False) + '\n')
            f.flush(); n += len(chunk)
            el = time.time() - t0
            print(f'{n}/{len(todo)} {n / el:.1f} seg/s', file=sys.stderr, flush=True)

if __name__ == '__main__':
    main()
