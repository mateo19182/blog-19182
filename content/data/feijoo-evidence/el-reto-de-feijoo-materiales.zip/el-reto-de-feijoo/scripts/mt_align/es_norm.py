"""18th-c. Spanish (BNE OCR of TCU first editions) → modern spelling, lexicon-guided.
Lexicon = modern forms from data/feijoo/tcu_1-3.jsonl (filosofia.org), keyed by accent-folded form."""
import re, json, unicodedata, collections, functools, os

ROOT = os.path.join(os.path.dirname(__file__), '..', '..')

def fold(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s.lower()) if unicodedata.category(c) != 'Mn')

WORD = re.compile(r"[A-Za-zÀ-ÿñÑçÇſ]+")

@functools.lru_cache(1)
def lexicon():
    cnt = collections.Counter()
    for l in open(os.path.join(ROOT, 'data/feijoo/tcu_1-3.jsonl')):
        cnt.update(w.lower() for w in WORD.findall(json.loads(l)['text']))
    best = {}
    for w, n in cnt.items():
        k = fold(w)
        if k not in best or n > cnt[best[k]]: best[k] = w
    return best, {fold(w): n for w, n in cnt.items()}

# OCR confusions (long s) then orthographic modernisations; each is (old, new) on folded text
OCR = [('f', 's'), ('ñ', 'st'), ('il', 'st'), ('ll', 'st'), ('fi', 'st'), ('ii', 'st'), ('fl', 'st'), ('ft', 'st'),
       ('li', 'st'), ('ni', 'st'), ('fs', 'ss'), ('fs', 's')]
ORTH = [('ss', 's'), ('ph', 'f'), ('th', 't'), ('qua', 'cua'), ('quo', 'cuo'), ('x', 'j'), ('v', 'u'), ('u', 'v'),
        ('y', 'i'), ('i', 'y'), ('b', 'v'), ('v', 'b'), ('ch', 'c'), ('ch', 'qu'), ('ç', 'z'), ('z', 'c'), ('g', 'j'),
        ('mm', 'm'), ('pt', 't'), ('h', ''), ('', 'h'), ('rr', 'r'), ('ct', 't'), ('sc', 'c'), ('mpt', 'nt'),
        ('pro', 'pro'), ('ae', 'e'), ('oe', 'e')]
FIXED = {'q': 'que', 'mui': 'muy', 'hai': 'hay', 'oy': 'hoy', 'aora': 'ahora', 'assi': 'así', 'afsi': 'así', 'vn': 'un',
         'vna': 'una', 'deste': 'de este', 'desta': 'de esta', 'dél': 'de él', 'proprio': 'propio', 'proprios': 'propios',
         'proprias': 'propias', 'propria': 'propia', 'y': 'y', 'o': 'o', 'fu': 'su', 'fus': 'sus', 'fe': 'se', 'fi': 'si',
         'fin': 'sin', 'fon': 'son', 'fer': 'ser', 'efte': 'este', 'efto': 'esto', 'efta': 'esta', 'mifmo': 'mismo', 'u': 'u',
         'quando': 'cuando', 'quanto': 'cuanto', 'quantos': 'cuantos', 'quanta': 'cuanta', 'quantas': 'cuantas',
         'qual': 'cual', 'quales': 'cuales', 'qualquiera': 'cualquiera', 'quatro': 'cuatro', 'dixo': 'dijo',
         'exemplo': 'ejemplo', 'exemplos': 'ejemplos', 'aunque': 'aunque', 'para': 'para', 'por': 'por'}

def _subs(w, rules):
    for a, b in rules:
        if a == '':
            if not w.startswith('h'): yield 'h' + w
            continue
        i = w.find(a)
        while i >= 0:
            yield w[:i] + b + w[i + len(a):]
            i = w.find(a, i + 1)

@functools.lru_cache(200000)
def norm_word(w):
    lex, freq = lexicon()
    lw = fold(w.replace('ſ', 's'))
    if lw in FIXED: out = FIXED[lw]
    elif lw in lex and freq[lw] >= 5: out = lex[lw]
    elif lw in lex:  # rare exact hit (often an old form kept in quotes): prefer a much commoner modernisation
        alt = [y for y in _subs(lw, ORTH) if freq.get(y, 0) > 20 * freq[lw]]
        out = lex[max(alt, key=freq.get)] if alt else lex[lw]
    else:
        out, seen, frontier = None, {lw}, [lw]
        for depth, rules in enumerate([OCR + ORTH, OCR + ORTH, ORTH]):
            nxt, hits = [], []
            for x in frontier:
                for y in _subs(x, rules):
                    if y in seen: continue
                    seen.add(y)
                    if y in lex: hits.append(y)
                    nxt.append(y)
            if hits:
                out = lex[max(hits, key=lambda h: freq.get(h, 0))]; break
            frontier = nxt[:400]
        if out is None:  # deterministic modernisation only
            out = lw
            for a, b in [('ph', 'f'), ('th', 't'), ('qua', 'cua'), ('quo', 'cuo'), ('ç', 'z'), ('ss', 's')]:
                out = out.replace(a, b)
    if w[:1].isupper(): out = out[:1].upper() + out[1:]
    return out

HEAD = re.compile(r'^(\W*\d+\W*)?\s*(Discurso|Discurfo|Paradox|Theatro|Theatr|Consectario|Prologo|Prólogo)\b.*$|^\W*\d{1,3}\W*$', re.I)

def clean_page(txt):
    """BNE page OCR → (list of (para_num|None, text)). Drops running heads, joins hyphenation."""
    lines = [l.rstrip() for l in txt.splitlines()]
    keep = []
    for l in lines:
        s = l.strip()
        if not s: continue
        if len(s.split()) <= 6 and HEAD.match(s): continue
        keep.append(s)
    # join; paragraph numbers appear as leading integers
    out, cur, num = [], [], None
    for s in keep:
        m = re.match(r'^(\d{1,3})\s+([A-ZÁÉÍÓÚ¿¡].*)$', s)
        if m:
            if cur: out.append((num, cur))
            num, cur = int(m.group(1)), [m.group(2)]
        else:
            cur.append(s)
    if cur: out.append((num, cur))
    res = []
    for n, ls in out:
        t = ''
        for s in ls:
            if t.endswith(('-', '±', '¬', '=')): t = t[:-1] + s
            elif t and s[:1] in ',;:.': t += s
            else: t += (' ' if t else '') + s
        res.append((n, t))
    return res

def norm_text(t):
    t = t.replace('&', 'y').replace('ſ', 's')
    t = re.sub(r'\s+([,;:.])', r'\1', t)
    return WORD.sub(lambda m: norm_word(m.group()), t)

if __name__ == '__main__':
    import sys
    for n, t in clean_page(open(sys.argv[1]).read()):
        print(n, '|', norm_text(t)[:600])
