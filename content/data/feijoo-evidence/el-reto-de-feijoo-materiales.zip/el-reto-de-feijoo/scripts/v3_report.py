#!/usr/bin/env python3
"""Summarise a match_v3 eval json: recall at judging cut-offs for v2 port vs v3 (planted by level, real positives)."""
import sys, json
r = json.load(open(sys.argv[1])); cuts = [int(x) for x in (sys.argv[2:] or [50, 100, 148, 300])]
print('model coef:', r.get('model_coef'))
for lv in (0, 1, 2, 3):
    for v in ('v2', 'v3'):
        xs = [x for k, x in r.get(f'{v}_planted_rank', {}).items() if k.endswith(f'.{lv}')]
        if xs: print(f'planted L{lv} {v}: ' + '  '.join(f'@{N} {sum(1 for x in xs if x and x <= N)}/{len(xs)}' for N in cuts))
real = list(r['v3_real_rank'])
for v in ('v2', 'v3'):
    rk = r[f'{v}_real_rank']
    print(f'real {v}: ' + '  '.join(f'@{N} {sum(1 for k in real if rk.get(k) and rk[k] <= N)}/{len(real)}' for N in cuts), rk)
