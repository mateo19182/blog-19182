"""Normalize 18th-c French OCR: de-hyphenate, fix long-s read as f using corpus frequencies, split sentences."""
import re, collections

def dehyphenate(lines):
    out = []
    for ln in lines:
        ln = ln.strip()
        if out and out[-1].endswith(('-', '¬')) and ln:
            out[-1] = out[-1][:-1] + ln
        else:
            out.append(ln)
    return ' '.join(x for x in out if x)

WORD = re.compile(r"[A-Za-zÀ-ÿ']+")

class LongS:
    """Replace f→s variants when the s-form is far more frequent in the corpus (self-supervised)."""
    def __init__(self, texts):
        self.freq = collections.Counter(w.lower() for t in texts for w in WORD.findall(t))
    def fix_word(self, w):
        if 'f' not in w.lower(): return w
        lw, best, bf = w.lower(), w, self.freq[w.lower()]
        idx = [i for i, c in enumerate(lw) if c == 'f']
        for mask in range(1, 1 << min(len(idx), 4)):
            cand = list(lw)
            for j, i in enumerate(idx[:4]):
                if mask >> j & 1: cand[i] = 's'
            cand = ''.join(cand)
            if self.freq[cand] > max(3 * bf, 2) and self.freq[cand] > self.freq[best.lower()]:
                best = ''.join(c2.upper() if c1.isupper() else c2 for c1, c2 in zip(w, cand))
        return best
    def __call__(self, text):
        return WORD.sub(lambda m: self.fix_word(m.group()), text)

SENT = re.compile(r'(?<=[.!?;:])\s+(?=[A-ZÀ-Ý«"(])')

def sentences(text, min_len=25):
    return [s.strip() for s in SENT.split(text) if len(s.strip()) >= min_len]
