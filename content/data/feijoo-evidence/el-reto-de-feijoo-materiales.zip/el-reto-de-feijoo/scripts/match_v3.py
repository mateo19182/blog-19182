#!/usr/bin/env python3
"""Matcher v3: article-level retrieval → in-region alignment → commonplace down-weighting → learned ranking.
Also runs a faithful CPU port of v2 (match_runs.py, WINF=1) on the same embeddings for comparison.

usage:
  match_v3.py [--fmt ia|kraken|hybrid|bsb] [--vols V ...] [--no-jds] [--plant data/eval/planted.jsonl]
              [--out out/v3/NAME] [--tsv out/v3_candidates_ia.tsv] [--threads 12]
  fmt=hybrid: kraken OCR for finished volumes, IA text for the rest (use this as OCR completes).
Design and parameters: notes/17-matcher-v3.md. CPU only (CUDA_VISIBLE_DEVICES forced empty)."""
import os, sys, re, json, math, time, argparse, collections
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
import v3_corpus as C
from v3_embed import embed, feijoo_texts

P = dict(
    K=8,            # kNN size for margin normalisation (as v2)
    KF=50,          # neighbours kept per Feijoo sentence (commonplace spread)
    CH_W=8, CH_S=4, # Trévoux retrieval chunk: 8 sentences, stride 4
    Q_W=8, Q_S=4,   # Feijoo query unit: whole paragraph, or 8-sentence sub-units of long paragraphs
    TOPK_DENSE=12, TOPK_LEX=6,   # chunks retrieved per query unit
    PAD=12,         # region = retrieved chunks ± PAD sentences (clipped to the volume)
    MERGE=16,       # chunks of one volume closer than this merge into one region
    TAU=1.0,        # margin baseline for alignment credit
    CP_COS=0.55, CP_REL=0.92,    # commonplace: other articles within 0.92×top1 cos (and ≥0.55)
    DUP_COS=0.85,
    SEED_M=1.06,    # sentence-level seed: margin of a global top-8 neighbour   # Trévoux sentence near-duplicated elsewhere in the corpus
)
LATIN = set('et in est non ad cum quod ut qui quae sed nec enim esse sunt atque per ab ex quam etiam vel autem ita sic hoc haec ille '
            'nihil erit quid tam nam ubi dum omnia omnes sua suo suis eius ergo igitur quoque inter apud sine'.split())

def same_text(a, b):
    """Shared quotation (Latin tag, verse): the ES and FR sides are nearly the same string, so the match proves nothing."""
    wa, wb = set(re.findall(r'[a-z]{3,}', C.fold(a))), set(re.findall(r'[a-z]{3,}', C.fold(b).replace('f', 's')))
    wa = {w.replace('f', 's') for w in wa}
    return len(wa) >= 4 and len(wa & wb) / len(wa) > 0.5

def log(*a): print(time.strftime('%H:%M:%S'), *a, file=sys.stderr, flush=True)

def latin_score(s):
    w = re.findall(r'[a-zæœ]+', s.lower())
    return sum(x in LATIN for x in w) / max(len(w), 1)

def anchors5(s):   # v2's fingerprint (kept verbatim for the v2 port)
    return {C.fold(t)[:5] for t in re.findall(r"[A-ZÀ-Ý][a-zà-ÿ]{3,}|\d{2,}", s)}

def anchors4(s):   # v3 lexical channel: proper-name 4-char stems + numbers
    out = {C.fold(t)[:4] for t in re.findall(r"[A-ZÀ-Ý][a-zà-ÿ]{3,}", s)}
    return out | {n for n in re.findall(r"\d{2,4}", s)}

# ------------------------------------------------------------------ corpus
def load_trevoux(fmt, vols, jds=True, kraken_done=None):
    if fmt == 'hybrid':
        # kraken_done: optional snapshot file (one ia_id per line) so a run uses a fixed set even if the OCR finishes more meanwhile
        done = set(l.strip() for l in open(kraken_done) if l.strip()) & set(C.list_volumes('kraken')) if kraken_done \
            else set(C.list_volumes('kraken'))
        vols = vols or C.list_volumes('ia')
        plan = [('kraken' if v in done else 'ia', v) for v in vols]
    else:
        plan = [(fmt, v) for v in (vols or C.list_volumes(fmt))]
    if jds: plan.append(('jds', 'jds1682_amsterdam'))
    T, E = [], []
    for f, v in plan:
        S = C.LOADERS[f](v)
        e = embed([x['text'] for x in S], f, v)
        for x in S: x['g'] = len(T); T.append(x)
        E.append(e)
        log(f'{f} {v}: {len(S)}')
    return T, np.concatenate(E), plan

def load_feijoo(plant=None):
    F = C.feijoo_segments()
    if plant:
        F = F + [json.loads(l) for l in open(plant)]
    sents, wins, s_owner, w_owner = [], [], [], []
    for pi, x in enumerate(F):
        x['s0'] = len(sents)
        for k, s in enumerate(x['sents']): sents.append(s); s_owner.append((pi, k))
        for k, (a, b) in enumerate(zip(x['sents'], x['sents'][1:])): wins.append(a + ' ' + b); w_owner.append((pi, k))
    real = C.feijoo_segments()
    rs, _ = feijoo_texts(real)
    es = embed(rs, 'feijoo', 'sents')
    if plant:
        ps, _ = feijoo_texts(F[len(real):])
        es = np.concatenate([es, embed(ps, 'plant', os.path.basename(plant) + '.s')])
    # 2-sentence windows approximated by the normalised sum of their sentence vectors (saves a 27k-unit LaBSE pass)
    ew = np.stack([es[F[pi]['s0'] + k] + es[F[pi]['s0'] + k + 1] for pi, k in w_owner]) if w_owner else np.zeros((0, es.shape[1]), np.float32)
    ew /= np.linalg.norm(ew, axis=1, keepdims=True)
    return F, sents, wins, s_owner, w_owner, es, ew

# ------------------------------------------------------------------ global kNN statistics
def knn_stats(Q, E_T, K, KF, block=256):
    """For each query row: top-KF (cos, idx) over T. Returns vals, idx (float32/int64)."""
    import torch
    Qt, Tt = torch.from_numpy(Q), torch.from_numpy(E_T)
    V, I = [], []
    for i in range(0, len(Q), block):
        v, ix = (Qt[i:i + block] @ Tt.T).topk(KF, dim=1)
        V.append(v.numpy()); I.append(ix.numpy())
    return np.concatenate(V), np.concatenate(I)

def t_knn_stats(E_T, Fall, K, block=8192):
    import torch
    Ft, Tt = torch.from_numpy(Fall), torch.from_numpy(E_T)
    out = np.zeros(len(E_T), np.float32)
    for j in range(0, len(E_T), block):
        out[j:j + block] = (Tt[j:j + block] @ Ft.T).topk(K, dim=1).values.mean(1).numpy()
    return out

# ------------------------------------------------------------------ v2 port (match_runs.py, WINF=1)
def run_v2(F, sents, wins, s_owner, w_owner, T, sv, si, wv, wi, t_knn, K=8, MIN_LEN=40, DI=4, DJ=12):
    units = []   # v2's F list: sentences then windows, len ≥ 40
    for n, s in enumerate(sents):
        if len(s) >= MIN_LEN: units.append((s, s_owner[n][0], sv[n, :K], si[n, :K]))
    for n, s in enumerate(wins):
        if len(s) >= MIN_LEN: units.append((s, w_owner[n][0], wv[n, :K], wi[n, :K]))
    good = []
    for i, (s, pi, v, ix) in enumerate(units):
        fk = v.mean(); fa = anchors5(s)
        for k in range(K):
            j = int(ix[k]); m = float(v[k] / ((fk + t_knn[j]) / 2))
            anch = len(fa & anchors5(T[j]['text']))
            if m > 1.08 or (anch >= 2 and m > 1.0):
                good.append({'i': i, 'j': j, 'm': m, 'anch': anch, 'fpara': F[pi]['para'], 'pi': pi})
    good.sort(key=lambda p: (T[p['j']]['vol'], p['i']))
    parent = list(range(len(good)))
    def find(a):
        while parent[a] != a: parent[a] = parent[parent[a]]; a = parent[a]
        return a
    by = collections.defaultdict(list)
    for n, p in enumerate(good): by[T[p['j']]['vol']].append(n)
    for ns in by.values():
        for ai, a in enumerate(ns):
            pa = good[a]
            for b in ns[ai + 1:]:
                pb = good[b]
                if pb['i'] - pa['i'] > DI: break
                if abs(T[pb['j']]['pos'] - T[pa['j']]['pos']) <= DJ and pb['i'] != pa['i']:
                    parent[find(a)] = find(b)
    cl = collections.defaultdict(list)
    for n in range(len(good)): cl[find(n)].append(good[n])
    runs = []
    def rec(ps, single=False):
        f0 = F[ps[0]['pi']]
        return {'score': 0, 'n': len(ps), 'vol': f0['vol'], 'disc': f0['disc'], 'title': f0['title'], 'para': f0['para'],
                'src': T[ps[0]['j']]['vol'], 'single': single,
                'pairs': [{'m': round(p['m'], 3), 'anch': p['anch'], 'es': units[p['i']][0], 'fr': T[p['j']]['text'],
                           'pid': F[p['pi']]['pid'], 'fpara': p['fpara'], 'tpos': T[p['j']]['pos'],
                           'add': F[p['pi']].get('add')} for p in ps]}
    for ps in cl.values():
        best = {}
        for p in ps:
            if p['i'] not in best or p['m'] > best[p['i']]['m']: best[p['i']] = p
        ps = sorted(best.values(), key=lambda p: p['i'])
        if len(ps) < 2: continue
        r = rec(ps); r['score'] = round(sum(max(p['m'] - 1, 0) for p in ps) + 0.05 * sum(p['anch'] for p in ps), 3)
        runs.append(r)
    in_run = {(p['pid'], p['tpos']) for r in runs for p in r['pairs']}
    for p in good:
        if p['m'] >= 1.15 and len(units[p['i']][0]) >= 80 and (F[p['pi']]['pid'], T[p['j']]['pos']) not in in_run:
            r = rec([p], True); r['score'] = round(p['m'] - 1 + 0.05 * p['anch'], 3); runs.append(r)
    runs.sort(key=lambda r: -r['score'])
    return runs

# ------------------------------------------------------------------ v3
def center(E):
    E = E - E.mean(0, keepdims=True)
    return E / np.linalg.norm(E, axis=1, keepdims=True)

def pool(Ec, spans):
    out = np.stack([Ec[a:b].sum(0) for a, b in spans])
    return out / np.maximum(np.linalg.norm(out, axis=1, keepdims=True), 1e-9)

def chunks_of(T):
    spans, vol_of = [], []
    start = 0
    for g in range(1, len(T) + 1):
        if g == len(T) or T[g]['vol'] != T[start]['vol']:
            n = g - start
            for a in range(0, max(n - P['CH_W'], 0) + 1, P['CH_S']):
                spans.append((start + a, start + min(a + P['CH_W'], n)))
            if n > P['CH_W'] and (n - P['CH_W']) % P['CH_S']:
                spans.append((g - P['CH_W'], g))
            start = g
    return spans

def queries_of(F):
    Q = []   # (pi, s_lo, s_hi) in global sentence index
    for pi, x in enumerate(F):
        n = len(x['sents'])
        if n == 0: continue
        if n <= P['Q_W'] + 2: Q.append((pi, x['s0'], x['s0'] + n))
        else:
            for a in range(0, n - 2, P['Q_S']):
                Q.append((pi, x['s0'] + a, x['s0'] + min(a + P['Q_W'], n)))
    return Q

def csls(A, B, k=10, block=2048):
    """Cross-domain similarity local scaling (Conneau et al. 2018): 2cos − r_A − r_B (hubness correction)."""
    import torch
    At, Bt = torch.from_numpy(A), torch.from_numpy(B)
    rA = np.concatenate([(At[i:i + block] @ Bt.T).topk(k, dim=1).values.mean(1).numpy() for i in range(0, len(A), block)])
    rB = np.concatenate([(Bt[i:i + block] @ At.T).topk(k, dim=1).values.mean(1).numpy() for i in range(0, len(B), block)])
    return rA, rB

def lex_matrices(F, Q, T, spans, sents):
    """Sparse idf-weighted anchor vectors for query units and chunks (vocab from chunks)."""
    from scipy import sparse
    t_anch = [anchors4(x['text']) for x in T]
    ch_sets = [set().union(*t_anch[a:b]) for a, b in spans]
    df = collections.Counter(a for s in ch_sets for a in s)
    q_sets = [set().union(*[anchors4(sents[k]) for k in range(lo, hi)]) for _, lo, hi in Q]
    qdf = collections.Counter(a for s in q_sets for a in s)
    n, nq = len(ch_sets), len(q_sets)
    vocab = {a: i for i, a in enumerate(a for a in df if df[a] / n < 0.02 and qdf.get(a, 0) / max(nq, 1) < 0.03)}
    idf = np.zeros(len(vocab), np.float32)
    for a, i in vocab.items(): idf[i] = math.log(n / (1 + df[a]))
    def mat(sets, w):
        r, c, v = [], [], []
        for i, s in enumerate(sets):
            for a in s:
                if a in vocab: r.append(i); c.append(vocab[a]); v.append(w[vocab[a]])
        return sparse.csr_matrix((v, (r, c)), shape=(len(sets), len(vocab)), dtype=np.float32)
    ones = np.ones(len(vocab), np.float32)
    return mat(q_sets, idf), mat(ch_sets, ones), vocab, idf, t_anch

def lis_len(xs):
    import bisect
    d = []
    for x in xs:
        k = bisect.bisect_left(d, x)
        if k == len(d): d.append(x)
        else: d[k] = x
    return len(d)

FEATS = ['credit', 'maxm', 'cover', 'ordered', 'lex', 'dense', 'lexq', 'nsent', 'topcos', 'cpw', 'latin', 'nmatch']   # 'local3' (densest 3-sentence stretch) was tried and lowered real recall; kept as a logged feature only

def run_v3(F, sents, wins, s_owner, w_owner, es, ew, T, E_T, sv, si, wv, wi, t_knn):
    import torch
    t0 = time.time()
    # --- commonplace weights, Feijoo side: how many distinct articles the sentence matches about equally well
    art_key = np.array([hash((x['vol'], x['art'] if x['art'] >= 0 else x['pos'] // 60)) for x in T])
    f_w = np.ones(len(sents), np.float32)
    for n in range(len(sents)):
        top = sv[n, 0]
        close = sv[n] >= max(P['CP_COS'], P['CP_REL'] * top)
        k = len(set(art_key[si[n][close]].tolist()))
        f_w[n] = 1.0 / (1.0 + math.log1p(max(k - 1, 0)))
        if latin_score(sents[n]) > 0.25: f_w[n] *= 0.5
    f_knn = sv[:, :P['K']].mean(1)
    # --- retrieval units
    spans = chunks_of(T); Q = queries_of(F)
    Ec_T, Ec_F = center(E_T), center(es)
    CH, QV = pool(Ec_T, spans), pool(Ec_F, [(lo, hi) for _, lo, hi in Q])
    rQ, rC = csls(QV, CH)
    Lq, Lc, vocab, idf, t_anch = lex_matrices(F, Q, T, spans, sents)
    log(f'v3: {len(spans)} chunks, {len(Q)} query units, lex vocab {len(vocab)}')
    LEX = (Lq @ Lc.T).tocsr()
    qnorm = np.sqrt(np.asarray(Lq.multiply(Lq).sum(1)).ravel() / np.maximum(idf.mean(), 1e-6)) + 1.0
    CHt = torch.from_numpy(CH)
    ch_vol = [T[a]['vol'] for a, _ in spans]
    cand = {}   # (pi, vol) -> list of (chunk, dense, lex)
    for qi in range(0, len(Q), 512):
        sim = (torch.from_numpy(QV[qi:qi + 512]) @ CHt.T).numpy()
        cs = 2 * sim - rQ[qi:qi + 512, None] - rC[None, :]
        for r in range(cs.shape[0]):
            q = qi + r; pi = Q[q][0]
            lx = LEX.getrow(q).toarray().ravel() / qnorm[q]
            top_d = np.argpartition(-cs[r], P['TOPK_DENSE'])[:P['TOPK_DENSE']]
            top_l = np.argpartition(-lx, P['TOPK_LEX'])[:P['TOPK_LEX']] if lx.any() else []
            for c in set(top_d.tolist()) | {int(c) for c in top_l if lx[c] > 0}:
                cand.setdefault((pi, ch_vol[c]), []).append((c, float(cs[r, c]), float(lx[c])))
    # sentence-level seeds: any Feijoo sentence/window whose global top-8 neighbour has margin > SEED_M adds that chunk
    import bisect
    starts = [a for a, _ in spans]
    q_of_s = {}
    for q, (pi, lo, hi) in enumerate(Q):
        for n in range(lo, hi): q_of_s.setdefault(n, q)
    wk_all = np.array([(f_knn[F[pi]['s0'] + k] + f_knn[F[pi]['s0'] + k + 1]) / 2 for pi, k in w_owner]) if w_owner else np.zeros(0)
    n_seed = 0
    for vals, idxs, owner, kk in ((sv, si, s_owner, f_knn), (wv, wi, w_owner, wk_all)):
        for n in range(len(owner)):
            pi, k = owner[n]
            m = vals[n, :P['K']] / ((kk[n] + t_knn[idxs[n, :P['K']]]) / 2)
            q = q_of_s.get(F[pi]['s0'] + k)
            if q is None: continue
            for j in idxs[n, :P['K']][m > P['SEED_M']]:
                c = bisect.bisect_right(starts, int(j)) - 1
                d = float(2 * QV[q] @ CH[c] - rQ[q] - rC[c])
                cand.setdefault((pi, ch_vol[c]), []).append((c, d, 0.0)); n_seed += 1
    log(f'v3: retrieval {time.time() - t0:.0f}s, {len(cand)} (paragraph, volume) pairs ({n_seed} sentence seeds)')
    # --- regions + alignment
    vol_lo, vol_hi = {}, {}
    for x in T: vol_lo.setdefault(x['vol'], x['g']); vol_hi[x['vol']] = x['g'] + 1
    s_of_para = collections.defaultdict(list)
    for n, (pi, k) in enumerate(s_owner): s_of_para[pi].append(n)
    w_of_para = collections.defaultdict(list)
    for n, (pi, k) in enumerate(w_owner): w_of_para[pi].append(n)
    Tt = torch.from_numpy(E_T)
    def t_dup_batch(js, block=1024):   # Trévoux commonplace: near-duplicates in other articles (one pass over E_T per block)
        res = {}
        for i in range(0, len(js), block):
            b = js[i:i + block]
            sim = (torch.from_numpy(E_T[b]) @ Tt.T) >= P['DUP_COS']
            for r, j in enumerate(b):
                hit = torch.nonzero(sim[r]).ravel().numpy()
                res[j] = len({art_key[h] for h in hit if art_key[h] != art_key[j]})
        return res
    out = []
    for (pi, vol), hits in cand.items():
        hits.sort(key=lambda h: spans[h[0]][0])
        groups, cur = [], [hits[0]]
        for h in hits[1:]:
            if spans[h[0]][0] - spans[cur[-1][0]][1] <= P['MERGE']: cur.append(h)
            else: groups.append(cur); cur = [h]
        groups.append(cur)
        fs = s_of_para[pi]; fw = w_of_para[pi]
        if not fs: continue
        pa = set().union(*[anchors4(sents[n]) for n in fs]) & vocab.keys()
        for g in groups:
            lo = max(vol_lo[vol], spans[g[0][0]][0] - P['PAD']); hi = min(vol_hi[vol], spans[g[-1][0]][1] + P['PAD'])
            E_r = E_T[lo:hi]; tk = t_knn[lo:hi]
            # Trévoux units: sentences + 2/3-sentence windows (normalised sums)
            U, Uk, Upos = [E_r], [tk], [np.arange(lo, hi)]
            for w in (2, 3):
                if hi - lo >= w:
                    s = sum(E_r[k:hi - lo - w + 1 + k] for k in range(w))
                    U.append(s / np.linalg.norm(s, axis=1, keepdims=True))
                    Uk.append(sum(tk[k:hi - lo - w + 1 + k] for k in range(w)) / w); Upos.append(np.arange(lo, hi - w + 1))
            U, Uk, Upos = np.concatenate(U), np.concatenate(Uk), np.concatenate(Upos)
            cs_s = es[fs] @ U.T                                             # Feijoo sentences
            m_s = cs_s / ((f_knn[fs, None] + Uk[None, :]) / 2)
            best = m_s.max(1); arg = m_s.argmax(1); bcos = cs_s[np.arange(len(fs)), arg]
            if fw:                                                           # Feijoo 2-windows credit both members
                cw = ew[fw] @ U.T
                wk = np.array([(f_knn[fs[w_owner[n][1]]] + f_knn[fs[w_owner[n][1] + 1]]) / 2 for n in fw])
                mw = cw / ((wk[:, None] + Uk[None, :]) / 2)
                bw, aw = mw.max(1), mw.argmax(1)
                for r, n in enumerate(fw):
                    k = w_owner[n][1]
                    for kk in (k, k + 1):
                        if bw[r] > best[kk]: best[kk], arg[kk], bcos[kk] = bw[r], aw[r], cw[r, aw[r]]
            tpos = Upos[arg]
            out.append({'pi': pi, 'vol': vol, 'lo': T[lo]['pos'], 'hi': T[hi - 1]['pos'], 'glo': lo, 'ghi': hi,
                        '_a': (fs, best, tpos, bcos, pa, g)})
    log(f'v3: aligned {len(out)} regions, {time.time() - t0:.0f}s; commonplace pass')
    strong = sorted({int(p) for c in out for p, b in zip(c['_a'][2], c['_a'][1]) if b > P['TAU'] + 0.05})
    dmap = t_dup_batch(strong)
    log(f'v3: duplicate check on {len(strong)} Trévoux sentences, {time.time() - t0:.0f}s')
    for c in out:
        fs, best, tpos, bcos, pa, g = c.pop('_a'); lo, hi = c['glo'], c['ghi']
        w = f_w[fs] * np.array([1.0 / (1.0 + math.log1p(dmap.get(int(p), 0))) for p in tpos])
        lat = np.array([latin_score(sents[n]) > 0.25 or same_text(sents[n], T[int(p)]['text']) for n, p in zip(fs, tpos)])
        credit = float((w * np.maximum(best - P['TAU'], 0)).sum())
        matched = best >= P['TAU'] + 0.03
        ordered = lis_len([int(p) for p, mm in zip(tpos, matched) if mm])
        ra = set().union(*t_anch[lo:hi]) & pa
        lex = float(sum(idf[vocab[a]] for a in ra))
        topc = np.sort(bcos)[-3:].mean()
        gain = w * np.maximum(best - P['TAU'], 0)   # densest 3-sentence stretch: a borrowing is local inside long paragraphs
        local3 = float(max(gain[k:k + 3].sum() for k in range(max(len(gain) - 2, 1))))
        c['f'] = dict(local3=local3, credit=credit, maxm=float(best.max()), cover=float(matched.mean()), ordered=ordered,
                      lex=lex, dense=max(h[1] for h in g), lexq=max(h[2] for h in g), nsent=math.log(len(fs)),
                      topcos=float(topc), cpw=float(w[matched].mean()) if matched.any() else 1.0,
                      latin=float(lat[matched].mean()) if matched.any() else 0.0, nmatch=int(matched.sum()))
        order = np.argsort(-best)[:6]
        c['pairs'] = [{'k': int(k), 'm': round(float(best[k]), 3), 'cos': round(float(bcos[k]), 3),
                       'tpos': T[int(tpos[k])]['pos'], 'g': int(tpos[k])} for k in sorted(order) if best[k] > 0.95]
    log(f'v3: alignment done, {len(out)} candidate regions, {time.time() - t0:.0f}s total')
    return out

def featmat(cands):
    X = np.array([[c['f'][k] for k in FEATS] for c in cands], np.float64)
    X[:, FEATS.index('lex')] = np.log1p(X[:, FEATS.index('lex')])
    X[:, FEATS.index('ordered')] = np.log1p(X[:, FEATS.index('ordered')])
    X[:, FEATS.index('nmatch')] = np.log1p(X[:, FEATS.index('nmatch')])
    return X

DEFAULT_W = None   # filled from the trained model file when present

def score(cands, model=None):
    X = featmat(cands)
    if model is None:   # hand-set fallback (used only if no trained model is available)
        w = dict(credit=3.0, maxm=4.0, cover=1.0, ordered=0.8, lex=0.6, dense=1.5, lexq=0.2, nsent=-0.3,
                 topcos=2.0, cpw=1.0, latin=-1.0, nmatch=0.3)
        s = X @ np.array([w[k] for k in FEATS])
    else:
        s = model.decision_function((X - model.mu_) / model.sd_)
    for c, v in zip(cands, s): c['score'] = float(v)
    return cands

GROUP_BONUS = 0.5

def group(cands, F, T):
    """Merge candidates of adjacent paragraphs (same discourse) whose Trévoux regions overlap → one reviewable packet."""
    G, idx = [], collections.defaultdict(list)
    for c in sorted(cands, key=lambda c: -c['score']):
        fp = F[c['pi']]; key = (c['vol'], fp['vol'], str(fp['disc']))
        for g in idx[key]:
            if (min(abs(F[m['pi']]['para'] - fp['para']) for m in g['members']) <= 2
                    and c['glo'] <= g['ghi'] + 10 and c['ghi'] >= g['glo'] - 10):
                g['members'].append(c); g['glo'] = min(g['glo'], c['glo']); g['ghi'] = max(g['ghi'], c['ghi'])
                break
        else:
            g = {'members': [c], 'score': c['score'], 'glo': c['glo'], 'ghi': c['ghi'], 'vol': c['vol']}
            G.append(g); idx[key].append(g)
    for g in G:   # packet score = best member + mild bonus for several distinct paragraphs aligning to the same region
        g['score'] = g['members'][0]['score'] + GROUP_BONUS * math.log(len({m['pi'] for m in g['members']}))
    G.sort(key=lambda g: -g['score'])
    return G

# ------------------------------------------------------------------ training (planted positives vs real candidates)
LEVEL_W = {0: 0.5, 1: 1.0, 2: 2.0, 3: 2.0}

class LR:
    def fit(self, X, y, w=None, C_=0.3):
        from sklearn.linear_model import LogisticRegression
        self.mu_, self.sd_ = X.mean(0), X.std(0) + 1e-6
        self.m = LogisticRegression(C=C_, class_weight='balanced', max_iter=2000).fit((X - self.mu_) / self.sd_, y, sample_weight=w)
        return self
    def decision_function(self, Z): return self.m.decision_function(Z)
    def coefs(self): return dict(zip(FEATS, np.round(self.m.coef_[0], 3).tolist()))

def planted_hit(c, F):
    f = F[c['pi']]
    return f.get('planted') and c['vol'] == f['src_vol'] and c['lo'] <= max(f['src_pos']) + 3 and c['hi'] >= min(f['src_pos']) - 3

# ------------------------------------------------------------------ main
def main():
    import v3_eval as EV
    ap = argparse.ArgumentParser()
    ap.add_argument('--fmt', default='ia'); ap.add_argument('--vols', nargs='*')
    ap.add_argument('--no-jds', action='store_true'); ap.add_argument('--plant')
    ap.add_argument('--out', default=f'{C.ROOT}/out/v3/ia'); ap.add_argument('--tsv')
    ap.add_argument('--threads', type=int, default=12); ap.add_argument('--no-v2', action='store_true')
    ap.add_argument('--model', default=f'{C.ROOT}/out/v3/model.json', help='trained weights (written when --plant is given)')
    ap.add_argument('--top', type=int, default=400, help='candidate groups written to the TSV')
    ap.add_argument('--kraken-done', help='hybrid only: file listing the finished kraken volumes to use (default: all with .done)')
    a = ap.parse_args()
    import torch; torch.set_num_threads(a.threads)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    t0 = time.time()
    T, E_T, plan = load_trevoux(a.fmt, a.vols, not a.no_jds, a.kraken_done)
    F, sents, wins, s_owner, w_owner, es, ew = load_feijoo(a.plant)
    log(f'{len(T)} Trévoux sentences in {len(plan)} volumes; {len(F)} Feijoo paragraphs, {len(sents)} sentences, {len(wins)} windows')
    sv, si = knn_stats(es, E_T, P['K'], P['KF'])
    wv, wi = knn_stats(ew, E_T, P['K'], P['K'])
    t_knn = t_knn_stats(E_T, np.concatenate([es, ew]), P['K'])
    log(f'kNN stats {time.time() - t0:.0f}s')
    res = {'params': P, 'fmt': a.fmt, 'volumes': len(plan), 'n_T': len(T), 'n_F': len(F), 'plan': plan}
    real = EV.regions(T, EV.REAL)
    planted_idx = [i for i, x in enumerate(F) if x.get('planted')]
    if not a.no_v2:
        t1 = time.time()
        runs = run_v2(F, sents, wins, s_owner, w_owner, T, sv, si, wv, wi, t_knn)
        res['v2_runtime_s'] = round(time.time() - t1)
        with open(a.out + '.v2port.runs.jsonl', 'w') as f:
            for r in runs: f.write(json.dumps(r, ensure_ascii=False) + '\n')
        runs_real = [r for r in runs if r['vol'] != 9]
        res['v2_real_rank'] = {k: EV.first_rank(runs_real, lambda r: EV.hit_v2run(r, set(p), rs)) for k, (p, rs) in real.items()}
        if planted_idx:
            sc = np.array([r['score'] for r in runs_real])
            pr = {}
            for i in planted_idx:
                f = F[i]; rs = [(f['src_vol'], min(f['src_pos']) - 3, max(f['src_pos']) + 3)]
                hits = [r['score'] for r in runs if r['vol'] == 9 and EV.hit_v2run(r, {f['pid']}, rs)]
                pr[f['pid']] = int((sc > max(hits)).sum()) + 1 if hits else None
            res['v2_planted_rank'] = pr
        log(f'v2 port: {len(runs_real)} runs; ranks {res["v2_real_rank"]}')
    t1 = time.time()
    cands = run_v3(F, sents, wins, s_owner, w_owner, es, ew, T, E_T, sv, si, wv, wi, t_knn)
    model = None
    if planted_idx:
        is_pl = np.array([bool(F[c['pi']].get('planted')) for c in cands])
        pos = np.array([bool(planted_hit(c, F)) for c in cands])
        gold_any = np.array([any(EV.hit_v3(c, F, set(p), rs) for p, rs in real.values()) for c in cands])
        neg = ~is_pl & ~gold_any
        X = featmat(cands)
        pas = np.array([int(F[c['pi']]['disc'][1:]) if is_pl[k] else -1 for k, c in enumerate(cands)])
        # 2-fold by passage: planted ranks use the model that did not see that passage
        # harder (condensed / paraphrased) plants weigh more: they look more like Feijoo than a full MT does
        lvw = np.array([LEVEL_W.get(F[c['pi']].get('level'), 1.0) if pos[k] else 1.0 for k, c in enumerate(cands)])
        folds = {}
        for fo in (0, 1):
            tr = (pos & (pas % 2 != fo)) | neg
            folds[fo] = LR().fit(X[tr], pos[tr], lvw[tr])
        model = LR().fit(X[pos | neg], pos[pos | neg], lvw[pos | neg])
        res['model_coef'] = model.coefs()
        json.dump({'feats': FEATS, 'mu': model.mu_.tolist(), 'sd': model.sd_.tolist(), 'coef': model.m.coef_[0].tolist(),
                   'intercept': float(model.m.intercept_[0]), 'params': P}, open(a.model, 'w'), indent=1)
        pr = {}
        for fo in (0, 1):
            score(cands, folds[fo])
            G = group(cands, F, T)
            Greal = [g for g in G if F[g['members'][0]['pi']]['vol'] != 9]
            sc = np.array([g['score'] for g in Greal])
            for i in planted_idx:
                if int(F[i]['disc'][1:]) % 2 != fo: continue
                hs = [g['score'] for g in G if any(m['pi'] == i and planted_hit(m, F) for m in g['members'])]
                pr[F[i]['pid']] = int((sc > max(hs)).sum()) + 1 if hs else None
        res['v3_planted_rank'] = pr
    elif os.path.exists(a.model):
        mj = json.load(open(a.model))
        model = LR(); model.mu_, model.sd_ = np.array(mj['mu']), np.array(mj['sd'])
        class M: pass
        model.m = M(); model.m.coef_ = np.array([mj['coef']]); model.m.intercept_ = np.array([mj['intercept']])
        model.decision_function = lambda Z: Z @ model.m.coef_[0] + model.m.intercept_[0]
    score(cands, model)
    G = group(cands, F, T)
    Greal = [g for g in G if F[g['members'][0]['pi']]['vol'] != 9]
    res['v3_runtime_s'] = round(time.time() - t1)
    res['v3_real_rank'] = {k: EV.first_rank(Greal, lambda g: any(EV.hit_v3(m, F, set(p), rs) for m in g['members']))
                           for k, (p, rs) in real.items()}
    res['n_groups'] = len(Greal)
    res['runtime_s'] = round(time.time() - t0)
    log(f'v3: {len(Greal)} groups; ranks {res["v3_real_rank"]}')
    json.dump(res, open(a.out + '.eval.json', 'w'), indent=1)
    with open(a.out + '.v3.groups.jsonl', 'w') as f:
        for g in Greal[:5000]:
            f.write(json.dumps(pack(g, F, T, sents), ensure_ascii=False) + '\n')
    if a.tsv: write_tsv(a.tsv, Greal[:a.top], F, T, sents, real)
    log(f'done in {time.time() - t0:.0f}s → {a.out}.*')

def pack(g, F, T, sents):
    ms = sorted(g['members'], key=lambda m: F[m['pi']]['para'])
    f0 = F[ms[0]['pi']]
    pairs = []
    for m in ms:
        f = F[m['pi']]
        for p in m['pairs']:
            pairs.append({'pid': f['pid'], 'm': p['m'], 'cos': p['cos'], 'es': f['sents'][p['k']], 'tpos': p['tpos'], 'fr': T[p['g']]['text']})
    return {'score': round(g['score'], 3), 'vol': f0['vol'], 'disc': f0['disc'], 'title': f0['title'],
            'pids': list(dict.fromkeys(F[m['pi']]['pid'] for m in ms)), 'labels': list(dict.fromkeys(F[m['pi']]['label'] for m in ms)),
            'add': any(F[m['pi']]['add'] for m in ms), 'ack': any(re.search(r'Tr[eé]v[oa]u', F[m['pi']]['text']) for m in ms),
            'src': g['vol'], 'lo': T[g['glo']]['pos'], 'hi': T[g['ghi'] - 1]['pos'],
            'art': T[g['glo']]['art'], 'leaf': [T[g['glo']]['leaf'], T[g['ghi'] - 1]['leaf']],
            'feats': {k: round(v, 3) for k, v in ms[0]['f'].items()}, 'pairs': pairs}

def write_tsv(path, G, F, T, sents, real):
    import v3_eval as EV
    pk = EV.judged_regions(T, EV.judged_packets())
    other = EV.regions(T, EV.OTHER_CASES)
    cols = ['rank', 'score', 'status', 'judged', 'feijoo', 'title', 'paras', 'post1st_add', 'cites_trevoux', 'trevoux_vol',
            'pos', 'article', 'n_pairs', 'max_m', 'lex', 'es_example', 'fr_example']
    with open(path, 'w') as f:
        f.write('\t'.join(cols) + '\n')
        for n, g in enumerate(G, 1):
            p = pack(g, F, T, sents)
            ms = g['members']; pids = set(p['pids'])
            nb = {f"{F[m['pi']]['vol']}.{F[m['pi']]['disc']}.{F[m['pi']]['para'] + d}" for m in ms for d in (-1, 0, 1)}
            j = [f"{k['id']}:{k['label']}" for k in pk if k['src'] == p['src'] and k['region'] and (k['pids'] & nb)
                 and k['region'][0] <= p['hi'] + 10 and k['region'][1] >= p['lo'] - 10]
            cs = [k for k, (pp, rs) in real.items() if any(EV.hit_v3(m, F, set(pp), rs) for m in ms)]
            cs += [k for k, (pp, rs) in other.items() if any(EV.hit_v3(m, F, set(pp), rs, disc_level=True) for m in ms)]
            status = 'case' if cs else 'judged' if j else 'new'
            best = max(p['pairs'], key=lambda x: x['m']) if p['pairs'] else {'es': '', 'fr': '', 'm': 0}
            clip = lambda s: re.sub(r'\s+', ' ', s)[:220]
            f.write('\t'.join(map(str, [n, round(g['score'], 3), status, ';'.join(cs + j), f"TC{p['vol']}.{p['disc']}", p['title'],
                                         ','.join(x.split('.')[-1] for x in p['pids']), int(p['add']), int(bool(p['ack'])),
                                         p['src'], f"{p['lo']}-{p['hi']}", p['art'], len(p['pairs']), p['feats']['maxm'],
                                         p['feats']['lex'], clip(best['es']), clip(best['fr'])])) + '\n')

if __name__ == '__main__':
    main()
