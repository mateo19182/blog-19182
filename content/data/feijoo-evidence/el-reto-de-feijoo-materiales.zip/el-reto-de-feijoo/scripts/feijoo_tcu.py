#!/usr/bin/env python3
"""Fetch and parse Teatro Crítico Universal I-III from filosofia.org (1777-79 RCIL edition).

  python3 feijoo_tcu.py fetch [VOLS]   # polite download into data/feijoo/raw/ (VOLS default 123)
  python3 feijoo_tcu.py parse [VOLS]   # 123 -> tcu_1-3.jsonl + explicit_citations.jsonl; 45 -> tcu_4-5.jsonl +
                                       #   explicit_citations_4-5.jsonl (1733 dare, notes/23); stats on stdout
"""
import html
import json
import re
import sys
import time
import urllib.request
from collections import Counter, defaultdict
from pathlib import Path

BASE = "https://www.filosofia.org/bjf/"
ROOT = Path(__file__).resolve().parent.parent / "data" / "feijoo"
RAW = ROOT / "raw"
UA = "Mozilla/5.0 (personal research corpus; polite, 3s delay)"

# Page id -> (kind, author). Only Feijoo's own texts go in the JSONL; the rest are kept raw.
FEIJOO_PAGES = {
    "1p3": "dedicatoria", "1p9": "prologo",
    "2p1": "dedicatoria", "2p6": "prologo", "2p8": "respuesta_martinez",
    "3p1": "dedicatoria", "3p6": "prologo_apologetico",
    "4p1": "dedicatoria", "4p6": "prologo",
    "5p1": "dedicatoria", "5p5": "prologo",
}
DISC_RE = re.compile(r"^[1-5]\d\d$")

CITE_PATTERNS = [
    ("trevoux", re.compile(r"Trev[oó]u[xzs]", re.I)),
    ("jds", re.compile(r"Diarios? de los Sabios|Journal des S[çc]avans|Diario de Par[ií]s", re.I)),
    ("academie_sciences", re.compile(r"(Historia|Memorias?) de la Academia Real de las Ciencias|Academia Real de las Ciencias", re.I)),
    ("nouvelles_rdl", re.compile(r"(Noticias|Nuevas) de la Rep[uú]blica de las Letras|Rep[uú]blica de las Letras", re.I)),
    ("phil_trans", re.compile(r"Transacciones Filos[oó]ficas|Philosophical Transactions", re.I)),
    ("acta_erud", re.compile(r"Acta Eruditorum|Actas de Leipsi", re.I)),
    ("memorias_generic", re.compile(r"Memorias de (?!Trev)[A-ZÁÉÍÓÚ]\w+")),
    ("periodistas", re.compile(r"\b(Diaristas?|Jornalistas?|Periodistas?)\b", re.I)),
]


def fetch(vols="123"):
    RAW.mkdir(parents=True, exist_ok=True)
    idx = get("bjft000")
    pages = [f"bjft{v}00" for v in vols]
    pages += sorted(set(re.findall(rf'href="(bjft[{vols}][0-9a-z]+)\.htm', idx)) - set(pages))
    for p in pages:
        get(p)


def get(page):
    f = RAW / f"{page}.htm"
    if not f.exists() or f.stat().st_size == 0:
        req = urllib.request.Request(BASE + page + ".htm", headers={"User-Agent": UA})
        f.write_bytes(urllib.request.urlopen(req, timeout=60).read())
        time.sleep(3)
    return f.read_text("utf-8")


def clean(s):
    s = re.sub(r"<br\s*/?>", " ", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = html.unescape(s).replace("\xa0", " ")
    return re.sub(r"\s+", " ", s).strip()


PAGE_RE = re.compile(r"\s*\[([0-9]+|[IVXLC]+)\]\s*")


def split_notes(text):
    """Pull {(a) ...} notes (Feijoo's marginal citations / Suplemento additions) out of text."""
    notes, out, depth, buf = [], [], 0, []
    for ch in text:
        if ch == "{":
            depth += 1
            if depth == 1:
                buf = []
                continue
        elif ch == "}" and depth:
            depth -= 1
            if depth == 0:
                notes.append("".join(buf).strip())
                out.append(" ")
                continue
        (buf if depth else out).append(ch)
    if depth:  # unterminated: note continues into following paragraphs
        notes.append("".join(buf).strip())
    return re.sub(r"\s+", " ", "".join(out)).strip(), notes, depth > 0


def note_kind(n):
    # short notes are the original marginal references; long prose ones are (mostly) Suplemento 1740 additions
    return "marginal_ref" if len(n) < 160 else "long_note"


def parse_page(pid, kind):
    src = RAW / f"bjft{pid}.htm"
    raw = src.read_text("utf-8").replace("&#123;", "{").replace("&#125;", "}")
    art = raw.split("<article>", 1)[1].split('<h3 class="ac c1">&#123;', 1)[0] if "<article>" in raw else raw
    art = art.split('<h3 class="ac c1">{', 1)[0]
    m = re.search(r'<h1[^>]*>(.*?)</h1>', art, re.S)
    title = clean(m.group(1)) if m else pid
    foot = re.search(r"Madrid 17\d\d, tomo \d, páginas? ([^<]+)</span></footer>", raw)
    vol = int(pid[0])
    disc_num = int(pid[1:]) if DISC_RE.match(pid) else None
    url = BASE + f"bjft{pid}.htm"
    recs, section, subsection, cur, in_note, seq = [], None, None, None, False, 0

    def rec(text, notes, pages, label, n, addition, cls=None):
        nonlocal seq
        seq += 1
        return {
            "vol": vol, "disc_num": disc_num, "kind": kind, "disc_title": title,
            "section": section, "subsection": subsection,
            "para_idx": n, "para_seq": seq, "para_label": label,
            "is_addition": addition, "text": text,
            "notes": [{"kind": note_kind(x), "text": x} for x in notes],
            "pages_1777_79": pages, "source_url": url + (f"#{label}" if label else ""),
        }

    main = None  # last main-text paragraph (additions attach to it)
    for tag, attrs, body in re.findall(r"<(h[2-5]|p)\b([^>]*)>(.*?)</\1>", art, re.S):
        if tag in ("h3", "h4"):
            section, subsection = clean(body.replace("<br>", " · ")), None
            continue
        if tag == "h5":
            subsection = clean(body)
            continue
        if tag == "h2":
            continue
        t = clean(body)
        if not t:
            continue
        m_id = re.search(r'id="([^"]+)"', attrs)
        label = m_id.group(1) if m_id else None
        cls = (re.search(r'class="([^"]+)"', attrs) or [None, ""])[1]
        pages = PAGE_RE.findall(t)
        t = PAGE_RE.sub(" ", t).strip()
        if in_note or t.startswith("{("):
            # Suplemento-style addition paragraph(s), filosofia.org wraps them in {…}
            text, notes, in_note = split_notes(("{" if in_note else "") + t)
            body_txt = " ".join(notes)
            mk = re.match(r"^\(([a-z])\)\s*", body_txt)
            marker = mk.group(1) if mk else None
            body_txt = body_txt[mk.end():] if mk else body_txt
            mn = re.match(r"^(\d+)\.?\s+", body_txt)
            r = rec(body_txt[mn.end():] if mn else body_txt, [], pages, label, None, True)
            r["addition_num"] = int(mn.group(1)) if mn else None
            r["attached_to_para"] = main["para_idx"] if main else None
            r["note_marker"] = marker
            recs.append(r)
            cur = r
            if re.search(r"\w", text) and main:
                main["text"] += " " + text
            continue
        text, notes, in_note = split_notes(t)
        num = re.match(r"^(\d+)\.?\s+", text) if (label and "pt" in label or re.match(r"^\d+\.\s", text)) else None
        if cur is not None and cls and re.match(r"(ac|sm|sp|ad)\b", cls):
            # unnumbered continuation (verse quote, 'sm' resumption) belongs to previous paragraph
            tgt = main or cur
            tgt["text"] = (tgt["text"] + "\n" + text).strip()
            tgt["notes"] += [{"kind": note_kind(x), "text": x} for x in notes]
            tgt["pages_1777_79"] += pages
            continue
        n = int(num.group(1)) if num else None
        cur = main = rec(text[num.end():] if num else text, notes, pages, label, n, False)
        recs.append(cur)
    for r in recs:
        # appended sub-texts answering critics of vol I (post-1726); not in the 1726 text as such
        r["later_part"] = bool(r["section"] and r["section"].startswith("Adici"))
        r["post_first_edition"] = r["is_addition"] or r["later_part"]
    return recs, (foot.group(1).strip() if foot else None)


def parse(vols="123"):
    pages = []
    for v in vols:
        for f in sorted(RAW.glob(f"bjft{v}*.htm")):
            pid = f.stem[4:]
            if DISC_RE.match(pid) and not pid.endswith("00"):
                pages.append((pid, "discurso"))
            elif pid in FEIJOO_PAGES:
                pages.append((pid, FEIJOO_PAGES[pid]))
    all_recs, stats = [], defaultdict(Counter)
    for pid, kind in pages:
        recs, pr = parse_page(pid, kind)
        for r in recs:
            r["page_range_1777_79"] = pr
        all_recs += recs
        s = stats[int(pid[0])]
        s["texts"] += 1
        s["discursos"] += kind == "discurso"
        s["paragraphs"] += len(recs)
        s["addition_paras"] += sum(r["is_addition"] for r in recs)
        s["words_main"] += sum(len(r["text"].split()) for r in recs if not r["is_addition"])
        s["words_additions"] += sum(len(r["text"].split()) for r in recs if r["is_addition"])
        s["words_notes"] += sum(len(n["text"].split()) for r in recs for n in r["notes"])
        s["notes"] += sum(len(r["notes"]) for r in recs)
    tag = f"{vols[0]}-{vols[-1]}"
    with open(ROOT / f"tcu_{tag}.jsonl", "w") as fo:
        for r in all_recs:
            fo.write(json.dumps(r, ensure_ascii=False) + "\n")

    cites = []
    for r in all_recs:
        chunks = [("text", r["text"])] + [("note", n["text"]) for n in r["notes"]]
        for where, txt in chunks:
            for cat, rx in CITE_PATTERNS:
                ms = list(rx.finditer(txt))
                if not ms:
                    continue
                cat2 = cat
                if cat == "trevoux":  # Dictionnaire de Trévoux is a different work from the Mémoires
                    dic = all(re.search(r"Diccionario[^.]{0,30}$", txt[max(0, m.start() - 45):m.start()]) for m in ms)
                    cat2 = "trevoux_dictionnaire" if dic else "trevoux_memoires"
                a, b = max(0, ms[0].start() - 300), min(len(txt), ms[-1].end() + 300)
                cites.append({
                    "category": cat2, "matches": [m.group(0) for m in ms], "vol": r["vol"],
                    "disc_num": r["disc_num"], "kind": r["kind"], "disc_title": r["disc_title"],
                    "section": r["section"], "para_idx": r["para_idx"], "para_label": r["para_label"],
                    "attached_to_para": r.get("attached_to_para"),
                    "is_addition": r["is_addition"], "later_part": r["later_part"],
                    "post_first_edition": r["post_first_edition"],
                    "in": where, "context": txt[a:b], "source_url": r["source_url"],
                })
    with open(ROOT / ("explicit_citations.jsonl" if vols == "123" else f"explicit_citations_{tag}.jsonl"), "w") as fo:
        for c in cites:
            fo.write(json.dumps(c, ensure_ascii=False) + "\n")
    for v in sorted(stats):
        print(v, dict(stats[v]))
    print("records", len(all_recs), "citations", Counter(c["category"] for c in cites))


if __name__ == "__main__":
    {"fetch": fetch, "parse": parse}[sys.argv[1]](*sys.argv[2:3])
