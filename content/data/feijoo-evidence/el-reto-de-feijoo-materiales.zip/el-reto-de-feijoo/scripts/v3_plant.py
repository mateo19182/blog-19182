#!/usr/bin/env python3
"""Build planted positives for the recall estimate: random Trévoux passages (IA text) → Spanish with opus-mt-fr-es (CPU),
at three condensation levels, written as synthetic Feijoo paragraphs (vol 9).
  L0 translation: 4 consecutive sentences, full MT.
  L1 abridged:    3 of 6 consecutive sentences, each cut at the first ';'/':' or at 25 words.
  L2 condensed:   3 of 10 sentences (preferring ones with names/numbers), each cut to ≤16 words at a clause boundary,
                  framed by two real Feijoo sentences from an unrelated paragraph (his own comment around the borrowing).
usage: v3_plant.py [N=50] [OUT=data/eval/planted.jsonl]"""
import os, sys, re, json, random
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.path.insert(0, os.path.dirname(__file__))
import v3_corpus as C

def ok(s):
    if not 45 <= len(s) <= 450: return False
    letters = sum(c.isalpha() or c.isspace() for c in s) / len(s)
    return letters > 0.86 and not C.HEAD.search(s) and len(re.findall(r'\b(quod|atque|enim|autem|sunt|esse|sed|cum|ut|quae|nec|ad|in|est)\b', s)) < 3

def clean(s):
    s = re.sub(r'\s8c\s|\s&\s', ' et ', s)
    s = re.sub(r"[^\w\s,.;:!?'’()«»-]", ' ', s)
    return re.sub(r'\s+([,.;:!?])', r'\1', re.sub(r'\s+', ' ', s)).strip()

def cut(s, n, first_clause=False):
    w = s.split()
    if first_clause:
        m = re.search(r'[;:]', s)
        if m and len(s[:m.start()].split()) >= 8: return s[:m.start()].rstrip(',') + '.'
    if len(w) <= n: return s
    part = ' '.join(w[:n]); k = max(part.rfind(','), part.rfind(';'), part.rfind(':'))
    if k > len(part) * 0.5: part = part[:k]
    return part.rstrip(',;:') + '.'

def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 50
    out = sys.argv[2] if len(sys.argv) > 2 else f'{C.ROOT}/data/eval/planted.jsonl'
    rng = random.Random(1729)
    vols = C.list_volumes('ia'); cache = {}
    picks = []
    while len(picks) < n:
        v = rng.choice(vols)
        S = cache.setdefault(v, C.load_ia(v))
        a = rng.randrange(150, len(S) - 150)
        run = S[a:a + 10]
        if len({x['art'] for x in run}) > 1 or not all(ok(x['text']) for x in run): continue
        if any(abs(a - b) < 400 and v == w for w, b, _ in picks): continue
        picks.append((v, a, run))
    import torch
    torch.set_num_threads(int(os.environ.get('MT_THREADS', 6)))
    from transformers import MarianMTModel, MarianTokenizer
    name = 'Helsinki-NLP/opus-mt-fr-es'
    tok, mt = MarianTokenizer.from_pretrained(name), MarianMTModel.from_pretrained(name).eval()
    def tr(xs):
        res = []
        for i in range(0, len(xs), 16):
            b = tok(xs[i:i + 16], return_tensors='pt', padding=True, truncation=True, max_length=256)
            with torch.inference_mode(): g = mt.generate(**b, num_beams=4, max_new_tokens=300)
            res += tok.batch_decode(g, skip_special_tokens=True)
        return res
    F = [x for x in C.feijoo_segments() if len(x['sents']) >= 3]
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w') as f:
        for i, (v, a, run) in enumerate(picks):
            es = tr([clean(x['text']) for x in run])
            anch = [len(re.findall(r'[A-ZÀ-Ý][a-zà-ÿ]{3,}|\d{2,}', x['text'][1:])) for x in run]
            l1 = sorted(rng.sample(range(6), 3))
            l2 = sorted(sorted(range(10), key=lambda k: (-anch[k], rng.random()))[:3])
            frame = rng.choice(F)['sents']
            levels = {
                0: ([es[k] for k in range(4)], list(range(4))),
                1: ([cut(es[k], 25, True) for k in l1], l1),
                2: ([frame[0]] + [cut(es[k], 16) for k in l2] + [frame[-1]], l2),
            }
            for lv, (sents, used) in levels.items():
                sents = [s for s in sents if len(s) >= C.F_MIN]
                f.write(json.dumps({'pid': f'P.{i}.{lv}', 'vol': 9, 'disc': f'P{i}', 'title': 'planted', 'para': lv,
                                    'label': None, 'section': None, 'add': False, 'post_first': False, 'planted': True,
                                    'level': lv, 'src_vol': v, 'src_pos': [run[k]['pos'] for k in used],
                                    'src_fr': [run[k]['text'] for k in used], 'text': ' '.join(sents), 'sents': sents},
                                   ensure_ascii=False) + '\n')
            print(i, v, a, file=sys.stderr, flush=True)


def level3(path=f'{C.ROOT}/data/eval/planted.jsonl'):
    """L3 paraphrase: same passages, pivot MT fr→en→es (different wording from the direct model), 4 of 10 sentences
    cut to ≤12 words, merged pairwise into 2 sentences with the pair order swapped, framed by 2 Feijoo sentences."""
    import torch
    torch.set_num_threads(int(os.environ.get('MT_THREADS', 6)))
    from transformers import MarianMTModel, MarianTokenizer
    def model(name):
        tok, mt = MarianTokenizer.from_pretrained(name), MarianMTModel.from_pretrained(name).eval()
        def tr(xs):
            res = []
            for i in range(0, len(xs), 16):
                b = tok(xs[i:i + 16], return_tensors='pt', padding=True, truncation=True, max_length=256)
                with torch.inference_mode(): g = mt.generate(**b, num_beams=4, max_new_tokens=300)
                res += tok.batch_decode(g, skip_special_tokens=True)
            return res
        return tr
    fr_en, en_es = model('Helsinki-NLP/opus-mt-fr-en'), model('Helsinki-NLP/opus-mt-en-es')
    recs = [json.loads(l) for l in open(path)]
    recs = [r for r in recs if r['level'] != 3]
    rng = random.Random(3)
    F = [x for x in C.feijoo_segments() if len(x['sents']) >= 3]
    cache, new = {}, []
    for r in [r for r in recs if r['level'] == 0]:
        S = cache.setdefault(r['src_vol'], C.load_ia(r['src_vol']))
        a = r['src_pos'][0]; run = S[a:a + 10]
        used = sorted(rng.sample(range(10), 4))
        es = en_es(fr_en([clean(run[k]['text']) for k in used]))
        es = [cut(s, 12).rstrip('.') for s in es]
        lower = lambda s: s[:1].lower() + s[1:]
        body = [es[2] + ', y ' + lower(es[3]) + '.', es[0] + '; ' + lower(es[1]) + '.']
        frame = rng.choice(F)['sents']
        sents = [s for s in [frame[0]] + body + [frame[-1]] if len(s) >= C.F_MIN]
        i = r['disc'][1:]
        new.append({**r, 'pid': f'P.{i}.3', 'para': 3, 'level': 3, 'src_pos': [run[k]['pos'] for k in used],
                    'src_fr': [run[k]['text'] for k in used], 'text': ' '.join(sents), 'sents': sents})
        print('L3', i, file=sys.stderr, flush=True)
    with open(path, 'w') as f:
        for r in recs + new: f.write(json.dumps(r, ensure_ascii=False) + '\n')

if __name__ == '__main__':
    level3() if '--level3' in sys.argv else main()
